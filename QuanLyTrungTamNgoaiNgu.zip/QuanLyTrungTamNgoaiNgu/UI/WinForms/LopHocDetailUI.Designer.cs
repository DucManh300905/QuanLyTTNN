﻿namespace WinForms
{
    partial class LopHocDetailUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.groupBoxThongTinLop = new System.Windows.Forms.GroupBox();
            this.lblPhongHoc = new System.Windows.Forms.Label();
            this.lblSiSo = new System.Windows.Forms.Label();
            this.lblGiaoVien = new System.Windows.Forms.Label();
            this.lblKhoaHoc = new System.Windows.Forms.Label();
            this.lblTenLop = new System.Windows.Forms.Label();
            this.lblMaLop = new System.Windows.Forms.Label();
            this.groupBoxHocVien = new System.Windows.Forms.GroupBox();
            this.dgvHocVien = new System.Windows.Forms.DataGridView();
            this.MaHV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemListening = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemReading = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemWriting = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemSpeaking = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemTrungBinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelThaoTac = new System.Windows.Forms.Panel();
            this.btnXoaHV = new System.Windows.Forms.Button();
            this.btnSuaHV = new System.Windows.Forms.Button();
            this.btnThemHV = new System.Windows.Forms.Button();
            this.groupBoxThongTinHocVien = new System.Windows.Forms.GroupBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtDiemSpeaking = new System.Windows.Forms.TextBox();
            this.txtDiemWriting = new System.Windows.Forms.TextBox();
            this.txtDiemReading = new System.Windows.Forms.TextBox();
            this.txtDiemListening = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtMaHV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxHocVienChuaCoLop = new System.Windows.Forms.GroupBox();
            this.dgvDangKyChiTiet = new System.Windows.Forms.DataGridView();
            this.MaHVChuaCoLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTenChuaCoLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KhoaHocChuaCoLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelHeader.SuspendLayout();
            this.groupBoxThongTinLop.SuspendLayout();
            this.groupBoxHocVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).BeginInit();
            this.panelThaoTac.SuspendLayout();
            this.groupBoxThongTinHocVien.SuspendLayout();
            this.groupBoxHocVienChuaCoLop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangKyChiTiet)).BeginInit();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panelHeader.Controls.Add(this.lblTieuDe);
            this.panelHeader.Controls.Add(this.btnDong);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Margin = new System.Windows.Forms.Padding(2);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1251, 49);
            this.panelHeader.TabIndex = 0;
            this.panelHeader.Paint += new System.Windows.Forms.PaintEventHandler(this.panelHeader_Paint_1);
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.White;
            this.lblTieuDe.Location = new System.Drawing.Point(15, 12);
            this.lblTieuDe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(222, 26);
            this.lblTieuDe.TabIndex = 1;
            this.lblTieuDe.Text = "CHI TIẾT LỚP HỌC";
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnDong.FlatAppearance.BorderSize = 0;
            this.btnDong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnDong.ForeColor = System.Drawing.Color.White;
            this.btnDong.Location = new System.Drawing.Point(1191, 8);
            this.btnDong.Margin = new System.Windows.Forms.Padding(2);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(45, 32);
            this.btnDong.TabIndex = 0;
            this.btnDong.Text = "X";
            this.btnDong.UseVisualStyleBackColor = false;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // groupBoxThongTinLop
            // 
            this.groupBoxThongTinLop.Controls.Add(this.lblPhongHoc);
            this.groupBoxThongTinLop.Controls.Add(this.lblSiSo);
            this.groupBoxThongTinLop.Controls.Add(this.lblGiaoVien);
            this.groupBoxThongTinLop.Controls.Add(this.lblKhoaHoc);
            this.groupBoxThongTinLop.Controls.Add(this.lblTenLop);
            this.groupBoxThongTinLop.Controls.Add(this.lblMaLop);
            this.groupBoxThongTinLop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxThongTinLop.Location = new System.Drawing.Point(15, 65);
            this.groupBoxThongTinLop.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxThongTinLop.Name = "groupBoxThongTinLop";
            this.groupBoxThongTinLop.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxThongTinLop.Size = new System.Drawing.Size(1221, 81);
            this.groupBoxThongTinLop.TabIndex = 1;
            this.groupBoxThongTinLop.TabStop = false;
            this.groupBoxThongTinLop.Text = "Thông tin lớp học";
            // 
            // lblPhongHoc
            // 
            this.lblPhongHoc.AutoSize = true;
            this.lblPhongHoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblPhongHoc.Location = new System.Drawing.Point(800, 49);
            this.lblPhongHoc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPhongHoc.Name = "lblPhongHoc";
            this.lblPhongHoc.Size = new System.Drawing.Size(94, 17);
            this.lblPhongHoc.TabIndex = 5;
            this.lblPhongHoc.Text = "Phòng: P.301";
            // 
            // lblSiSo
            // 
            this.lblSiSo.AutoSize = true;
            this.lblSiSo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSiSo.Location = new System.Drawing.Point(800, 24);
            this.lblSiSo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSiSo.Name = "lblSiSo";
            this.lblSiSo.Size = new System.Drawing.Size(114, 17);
            this.lblSiSo.TabIndex = 4;
            this.lblSiSo.Text = "Sĩ số tối đa: 0/30";
            // 
            // lblGiaoVien
            // 
            this.lblGiaoVien.AutoSize = true;
            this.lblGiaoVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblGiaoVien.Location = new System.Drawing.Point(400, 49);
            this.lblGiaoVien.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGiaoVien.Name = "lblGiaoVien";
            this.lblGiaoVien.Size = new System.Drawing.Size(167, 17);
            this.lblGiaoVien.TabIndex = 3;
            this.lblGiaoVien.Text = "Giáo viên: Nguyễn Văn A";
            // 
            // lblKhoaHoc
            // 
            this.lblKhoaHoc.AutoSize = true;
            this.lblKhoaHoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblKhoaHoc.Location = new System.Drawing.Point(400, 24);
            this.lblKhoaHoc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKhoaHoc.Name = "lblKhoaHoc";
            this.lblKhoaHoc.Size = new System.Drawing.Size(114, 17);
            this.lblKhoaHoc.TabIndex = 2;
            this.lblKhoaHoc.Text = "Khóa học: IELTS";
            // 
            // lblTenLop
            // 
            this.lblTenLop.AutoSize = true;
            this.lblTenLop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblTenLop.Location = new System.Drawing.Point(15, 49);
            this.lblTenLop.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTenLop.Name = "lblTenLop";
            this.lblTenLop.Size = new System.Drawing.Size(134, 17);
            this.lblTenLop.TabIndex = 1;
            this.lblTenLop.Text = "Tên lớp: IELTS 6.0+";
            // 
            // lblMaLop
            // 
            this.lblMaLop.AutoSize = true;
            this.lblMaLop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblMaLop.Location = new System.Drawing.Point(15, 24);
            this.lblMaLop.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaLop.Name = "lblMaLop";
            this.lblMaLop.Size = new System.Drawing.Size(98, 17);
            this.lblMaLop.TabIndex = 0;
            this.lblMaLop.Text = "Mã lớp: L0001";
            // 
            // groupBoxHocVien
            // 
            this.groupBoxHocVien.Controls.Add(this.dgvHocVien);
            this.groupBoxHocVien.Controls.Add(this.panelThaoTac);
            this.groupBoxHocVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxHocVien.Location = new System.Drawing.Point(15, 162);
            this.groupBoxHocVien.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxHocVien.Name = "groupBoxHocVien";
            this.groupBoxHocVien.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxHocVien.Size = new System.Drawing.Size(898, 390);
            this.groupBoxHocVien.TabIndex = 2;
            this.groupBoxHocVien.TabStop = false;
            this.groupBoxHocVien.Text = "Danh sách học viên trong lớp";
            // 
            // dgvHocVien
            // 
            this.dgvHocVien.AllowUserToAddRows = false;
            this.dgvHocVien.AllowUserToDeleteRows = false;
            this.dgvHocVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHocVien.BackgroundColor = System.Drawing.Color.White;
            this.dgvHocVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHocVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHV,
            this.HoTen,
            this.NgaySinh,
            this.DiemListening,
            this.DiemReading,
            this.DiemWriting,
            this.DiemSpeaking,
            this.DiemTrungBinh});
            this.dgvHocVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHocVien.Location = new System.Drawing.Point(2, 18);
            this.dgvHocVien.Margin = new System.Windows.Forms.Padding(2);
            this.dgvHocVien.Name = "dgvHocVien";
            this.dgvHocVien.ReadOnly = true;
            this.dgvHocVien.RowHeadersWidth = 51;
            this.dgvHocVien.RowTemplate.Height = 24;
            this.dgvHocVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHocVien.Size = new System.Drawing.Size(894, 321);
            this.dgvHocVien.TabIndex = 1;
            this.dgvHocVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHocVien_CellClick);
            // 
            // MaHV
            // 
            this.MaHV.DataPropertyName = "MaHV";
            this.MaHV.FillWeight = 60F;
            this.MaHV.HeaderText = "Mã HV";
            this.MaHV.MinimumWidth = 6;
            this.MaHV.Name = "MaHV";
            this.MaHV.ReadOnly = true;
            // 
            // HoTen
            // 
            this.HoTen.DataPropertyName = "HoTen";
            this.HoTen.FillWeight = 120F;
            this.HoTen.HeaderText = "Họ và tên";
            this.HoTen.MinimumWidth = 6;
            this.HoTen.Name = "HoTen";
            this.HoTen.ReadOnly = true;
            // 
            // NgaySinh
            // 
            this.NgaySinh.DataPropertyName = "NgaySinh";
            this.NgaySinh.FillWeight = 80F;
            this.NgaySinh.HeaderText = "Ngày sinh";
            this.NgaySinh.MinimumWidth = 6;
            this.NgaySinh.Name = "NgaySinh";
            this.NgaySinh.ReadOnly = true;
            // 
            // DiemListening
            // 
            this.DiemListening.DataPropertyName = "DiemListening";
            this.DiemListening.FillWeight = 60F;
            this.DiemListening.HeaderText = "Listening";
            this.DiemListening.MinimumWidth = 6;
            this.DiemListening.Name = "DiemListening";
            this.DiemListening.ReadOnly = true;
            // 
            // DiemReading
            // 
            this.DiemReading.DataPropertyName = "DiemReading";
            this.DiemReading.FillWeight = 60F;
            this.DiemReading.HeaderText = "Reading";
            this.DiemReading.MinimumWidth = 6;
            this.DiemReading.Name = "DiemReading";
            this.DiemReading.ReadOnly = true;
            // 
            // DiemWriting
            // 
            this.DiemWriting.DataPropertyName = "DiemWriting";
            this.DiemWriting.FillWeight = 60F;
            this.DiemWriting.HeaderText = "Writing";
            this.DiemWriting.MinimumWidth = 6;
            this.DiemWriting.Name = "DiemWriting";
            this.DiemWriting.ReadOnly = true;
            // 
            // DiemSpeaking
            // 
            this.DiemSpeaking.DataPropertyName = "DiemSpeaking";
            this.DiemSpeaking.FillWeight = 60F;
            this.DiemSpeaking.HeaderText = "Speaking";
            this.DiemSpeaking.MinimumWidth = 6;
            this.DiemSpeaking.Name = "DiemSpeaking";
            this.DiemSpeaking.ReadOnly = true;
            // 
            // DiemTrungBinh
            // 
            this.DiemTrungBinh.DataPropertyName = "DiemTrungBinh";
            this.DiemTrungBinh.FillWeight = 70F;
            this.DiemTrungBinh.HeaderText = "TB";
            this.DiemTrungBinh.MinimumWidth = 6;
            this.DiemTrungBinh.Name = "DiemTrungBinh";
            this.DiemTrungBinh.ReadOnly = true;
            // 
            // panelThaoTac
            // 
            this.panelThaoTac.Controls.Add(this.btnXoaHV);
            this.panelThaoTac.Controls.Add(this.btnSuaHV);
            this.panelThaoTac.Controls.Add(this.btnThemHV);
            this.panelThaoTac.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelThaoTac.Location = new System.Drawing.Point(2, 339);
            this.panelThaoTac.Margin = new System.Windows.Forms.Padding(2);
            this.panelThaoTac.Name = "panelThaoTac";
            this.panelThaoTac.Size = new System.Drawing.Size(894, 49);
            this.panelThaoTac.TabIndex = 0;
            // 
            // btnXoaHV
            // 
            this.btnXoaHV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnXoaHV.FlatAppearance.BorderSize = 0;
            this.btnXoaHV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoaHV.ForeColor = System.Drawing.Color.White;
            this.btnXoaHV.Location = new System.Drawing.Point(254, 8);
            this.btnXoaHV.Margin = new System.Windows.Forms.Padding(2);
            this.btnXoaHV.Name = "btnXoaHV";
            this.btnXoaHV.Size = new System.Drawing.Size(105, 32);
            this.btnXoaHV.TabIndex = 2;
            this.btnXoaHV.Text = "Xóa";
            this.btnXoaHV.UseVisualStyleBackColor = false;
            this.btnXoaHV.Click += new System.EventHandler(this.btnXoaHV_Click);
            // 
            // btnSuaHV
            // 
            this.btnSuaHV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(196)))), ((int)(((byte)(15)))));
            this.btnSuaHV.FlatAppearance.BorderSize = 0;
            this.btnSuaHV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnSuaHV.ForeColor = System.Drawing.Color.White;
            this.btnSuaHV.Location = new System.Drawing.Point(127, 8);
            this.btnSuaHV.Margin = new System.Windows.Forms.Padding(2);
            this.btnSuaHV.Name = "btnSuaHV";
            this.btnSuaHV.Size = new System.Drawing.Size(105, 32);
            this.btnSuaHV.TabIndex = 1;
            this.btnSuaHV.Text = "Sửa điểm";
            this.btnSuaHV.UseVisualStyleBackColor = false;
            this.btnSuaHV.Click += new System.EventHandler(this.btnSuaHV_Click);
            // 
            // btnThemHV
            // 
            this.btnThemHV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnThemHV.FlatAppearance.BorderSize = 0;
            this.btnThemHV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemHV.ForeColor = System.Drawing.Color.White;
            this.btnThemHV.Location = new System.Drawing.Point(6, 8);
            this.btnThemHV.Margin = new System.Windows.Forms.Padding(2);
            this.btnThemHV.Name = "btnThemHV";
            this.btnThemHV.Size = new System.Drawing.Size(105, 32);
            this.btnThemHV.TabIndex = 0;
            this.btnThemHV.Text = "Thêm";
            this.btnThemHV.UseVisualStyleBackColor = false;
            this.btnThemHV.Click += new System.EventHandler(this.btnThemHV_Click);
            // 
            // groupBoxThongTinHocVien
            // 
            this.groupBoxThongTinHocVien.Controls.Add(this.dtpNgaySinh);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtDiemSpeaking);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtDiemWriting);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtDiemReading);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtDiemListening);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtHoTen);
            this.groupBoxThongTinHocVien.Controls.Add(this.txtMaHV);
            this.groupBoxThongTinHocVien.Controls.Add(this.label7);
            this.groupBoxThongTinHocVien.Controls.Add(this.label6);
            this.groupBoxThongTinHocVien.Controls.Add(this.label5);
            this.groupBoxThongTinHocVien.Controls.Add(this.label4);
            this.groupBoxThongTinHocVien.Controls.Add(this.label3);
            this.groupBoxThongTinHocVien.Controls.Add(this.label2);
            this.groupBoxThongTinHocVien.Controls.Add(this.label1);
            this.groupBoxThongTinHocVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxThongTinHocVien.Location = new System.Drawing.Point(917, 162);
            this.groupBoxThongTinHocVien.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxThongTinHocVien.Name = "groupBoxThongTinHocVien";
            this.groupBoxThongTinHocVien.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxThongTinHocVien.Size = new System.Drawing.Size(319, 390);
            this.groupBoxThongTinHocVien.TabIndex = 3;
            this.groupBoxThongTinHocVien.TabStop = false;
            this.groupBoxThongTinHocVien.Text = "Thông tin học viên";
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(112, 114);
            this.dtpNgaySinh.Margin = new System.Windows.Forms.Padding(2);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(192, 23);
            this.dtpNgaySinh.TabIndex = 13;
            // 
            // txtDiemSpeaking
            // 
            this.txtDiemSpeaking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDiemSpeaking.Location = new System.Drawing.Point(112, 276);
            this.txtDiemSpeaking.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiemSpeaking.Name = "txtDiemSpeaking";
            this.txtDiemSpeaking.Size = new System.Drawing.Size(192, 23);
            this.txtDiemSpeaking.TabIndex = 12;
            // 
            // txtDiemWriting
            // 
            this.txtDiemWriting.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDiemWriting.Location = new System.Drawing.Point(112, 236);
            this.txtDiemWriting.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiemWriting.Name = "txtDiemWriting";
            this.txtDiemWriting.Size = new System.Drawing.Size(192, 23);
            this.txtDiemWriting.TabIndex = 11;
            // 
            // txtDiemReading
            // 
            this.txtDiemReading.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDiemReading.Location = new System.Drawing.Point(112, 195);
            this.txtDiemReading.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiemReading.Name = "txtDiemReading";
            this.txtDiemReading.Size = new System.Drawing.Size(192, 23);
            this.txtDiemReading.TabIndex = 10;
            // 
            // txtDiemListening
            // 
            this.txtDiemListening.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDiemListening.Location = new System.Drawing.Point(112, 154);
            this.txtDiemListening.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiemListening.Name = "txtDiemListening";
            this.txtDiemListening.Size = new System.Drawing.Size(192, 23);
            this.txtDiemListening.TabIndex = 9;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtHoTen.Location = new System.Drawing.Point(112, 73);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(2);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(192, 23);
            this.txtHoTen.TabIndex = 8;
            // 
            // txtMaHV
            // 
            this.txtMaHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtMaHV.Location = new System.Drawing.Point(112, 32);
            this.txtMaHV.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaHV.Name = "txtMaHV";
            this.txtMaHV.Size = new System.Drawing.Size(192, 23);
            this.txtMaHV.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.Location = new System.Drawing.Point(15, 279);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Speaking";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.Location = new System.Drawing.Point(15, 238);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Writing";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(15, 197);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Reading";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(15, 157);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Listening";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(15, 116);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày sinh";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(15, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ và tên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(15, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã học viên";
            // 
            // groupBoxHocVienChuaCoLop
            // 
            this.groupBoxHocVienChuaCoLop.Controls.Add(this.dgvDangKyChiTiet);
            this.groupBoxHocVienChuaCoLop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxHocVienChuaCoLop.Location = new System.Drawing.Point(15, 557);
            this.groupBoxHocVienChuaCoLop.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxHocVienChuaCoLop.Name = "groupBoxHocVienChuaCoLop";
            this.groupBoxHocVienChuaCoLop.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxHocVienChuaCoLop.Size = new System.Drawing.Size(1221, 223);
            this.groupBoxHocVienChuaCoLop.TabIndex = 4;
            this.groupBoxHocVienChuaCoLop.TabStop = false;
            this.groupBoxHocVienChuaCoLop.Text = "📋 Danh sách học viên chưa có lớp";
            // 
            // dgvDangKyChiTiet
            // 
            this.dgvDangKyChiTiet.AllowUserToAddRows = false;
            this.dgvDangKyChiTiet.AllowUserToDeleteRows = false;
            this.dgvDangKyChiTiet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDangKyChiTiet.BackgroundColor = System.Drawing.Color.White;
            this.dgvDangKyChiTiet.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDangKyChiTiet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDangKyChiTiet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHVChuaCoLop,
            this.HoTenChuaCoLop,
            this.KhoaHocChuaCoLop});
            this.dgvDangKyChiTiet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDangKyChiTiet.Location = new System.Drawing.Point(2, 18);
            this.dgvDangKyChiTiet.Margin = new System.Windows.Forms.Padding(2);
            this.dgvDangKyChiTiet.Name = "dgvDangKyChiTiet";
            this.dgvDangKyChiTiet.ReadOnly = true;
            this.dgvDangKyChiTiet.RowHeadersWidth = 51;
            this.dgvDangKyChiTiet.RowTemplate.Height = 28;
            this.dgvDangKyChiTiet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDangKyChiTiet.Size = new System.Drawing.Size(1217, 203);
            this.dgvDangKyChiTiet.TabIndex = 0;
            // 
            // MaHVChuaCoLop
            // 
            this.MaHVChuaCoLop.DataPropertyName = "MaHV";
            this.MaHVChuaCoLop.FillWeight = 106.599F;
            this.MaHVChuaCoLop.HeaderText = "Mã học viên";
            this.MaHVChuaCoLop.MinimumWidth = 6;
            this.MaHVChuaCoLop.Name = "MaHVChuaCoLop";
            this.MaHVChuaCoLop.ReadOnly = true;
            // 
            // HoTenChuaCoLop
            // 
            this.HoTenChuaCoLop.DataPropertyName = "HoTen";
            this.HoTenChuaCoLop.FillWeight = 135.2228F;
            this.HoTenChuaCoLop.HeaderText = "Họ và tên";
            this.HoTenChuaCoLop.MinimumWidth = 6;
            this.HoTenChuaCoLop.Name = "HoTenChuaCoLop";
            this.HoTenChuaCoLop.ReadOnly = true;
            // 
            // KhoaHocChuaCoLop
            // 
            this.KhoaHocChuaCoLop.DataPropertyName = "TenKhoaHoc";
            this.KhoaHocChuaCoLop.FillWeight = 108.1782F;
            this.KhoaHocChuaCoLop.HeaderText = "Khóa học";
            this.KhoaHocChuaCoLop.MinimumWidth = 6;
            this.KhoaHocChuaCoLop.Name = "KhoaHocChuaCoLop";
            this.KhoaHocChuaCoLop.ReadOnly = true;
            // 
            // LopHocDetailUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1251, 792);
            this.Controls.Add(this.groupBoxHocVienChuaCoLop);
            this.Controls.Add(this.groupBoxThongTinHocVien);
            this.Controls.Add(this.groupBoxHocVien);
            this.Controls.Add(this.groupBoxThongTinLop);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "LopHocDetailUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chi tiết lớp học";
            this.Load += new System.EventHandler(this.LopHocDetail_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.groupBoxThongTinLop.ResumeLayout(false);
            this.groupBoxThongTinLop.PerformLayout();
            this.groupBoxHocVien.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).EndInit();
            this.panelThaoTac.ResumeLayout(false);
            this.groupBoxThongTinHocVien.ResumeLayout(false);
            this.groupBoxThongTinHocVien.PerformLayout();
            this.groupBoxHocVienChuaCoLop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangKyChiTiet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox groupBoxThongTinLop;
        private System.Windows.Forms.Label lblPhongHoc;
        private System.Windows.Forms.Label lblSiSo;
        private System.Windows.Forms.Label lblGiaoVien;
        private System.Windows.Forms.Label lblKhoaHoc;
        private System.Windows.Forms.Label lblTenLop;
        private System.Windows.Forms.Label lblMaLop;
        private System.Windows.Forms.GroupBox groupBoxHocVien;
        private System.Windows.Forms.DataGridView dgvHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHV;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemListening;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemReading;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemWriting;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemSpeaking;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemTrungBinh;
        private System.Windows.Forms.Panel panelThaoTac;
        private System.Windows.Forms.Button btnXoaHV;
        private System.Windows.Forms.Button btnSuaHV;
        private System.Windows.Forms.Button btnThemHV;
        private System.Windows.Forms.GroupBox groupBoxThongTinHocVien;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtDiemSpeaking;
        private System.Windows.Forms.TextBox txtDiemWriting;
        private System.Windows.Forms.TextBox txtDiemReading;
        private System.Windows.Forms.TextBox txtDiemListening;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtMaHV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxHocVienChuaCoLop;
        private System.Windows.Forms.DataGridView dgvDangKyChiTiet;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHVChuaCoLop;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTenChuaCoLop;
        private System.Windows.Forms.DataGridViewTextBoxColumn KhoaHocChuaCoLop;
    }
}