﻿using BLL.Interfaces;
using BLL.Repositories;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class KhoaHocUI : Form
    {
        private IKhoaHocService _khoaHocService;

        public KhoaHocUI()
        {
            InitializeComponent();
            _khoaHocService = new KhoaHocService();
        }

        private void LoadData()
        {
            dgvKhoaHoc.AutoGenerateColumns = false;
            dgvKhoaHoc.DataSource = _khoaHocService.GetAll().ToList();
        }
        private void KhoaHocUI_Load(object sender, EventArgs e)
        {
            LoadData();
        }



        private void dgvKhoaHoc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvKhoaHoc.Rows[e.RowIndex];

            txtMaKH.Text = row.Cells["colMaKH"].Value.ToString();
            txtTenKH.Text = row.Cells["colTenKH"].Value.ToString();
            txtTrinhDo.Text = row.Cells["colTrinhDo"].Value.ToString();
            txtSoBuoiHoc.Text = row.Cells["colSoBuoiHoc"].Value.ToString();
            txtThoiLuong.Text = row.Cells["colThoiLuong"].Value.ToString();
            txtHocPhi.Text = row.Cells["colHocPhi"].Value.ToString();
        }
        private KhoaHoc GetFormData()
        {
            return new KhoaHoc
            {
                MaKhoaHoc = txtMaKH.Text.Trim(),
                TenKhoaHoc = txtTenKH.Text.Trim(),
                TrinhDo = txtTrinhDo.Text.Trim(),
                SoBuoi = int.Parse(txtSoBuoiHoc.Text),
                ThoiLuong = int.Parse(txtThoiLuong.Text),
                HocPhi = decimal.Parse(txtHocPhi.Text)
            };
        }


        private void btnThemKH_Click(object sender, EventArgs e)
        {
            try
            {
                var kh = GetFormData();
                _khoaHocService.Add(kh);

                LoadData();
                ClearForm();

                MessageBox.Show("Thêm khóa học thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi");
            }
        }

        private void btnSuaKH_Click(object sender, EventArgs e)
        {
            try
            {
                var kh = GetFormData();
                _khoaHocService.Update(kh);

                LoadData();
                ClearForm();

                MessageBox.Show("Cập nhật thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi");
            }
        }

        private void btnXoaKH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaKH.Text))
            {
                MessageBox.Show("Vui lòng chọn khóa học cần xóa!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show(
                "Bạn có chắc chắn muốn xóa khóa học này?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes)
                return;

            try
            {
                _khoaHocService.Delete(txtMaKH.Text.Trim());

                LoadData();
                ClearForm();

                MessageBox.Show("Xóa khóa học thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        private void ClearForm()
        {
            txtMaKH.Clear();
            txtTenKH.Clear();
            txtThoiLuong.Clear();
            txtHocPhi.Clear();
            txtTrinhDo.Clear();
            txtSoBuoiHoc.Clear();
        }


        private async void btnTimKiem_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtTimKiem.Text.Trim();

                dgvKhoaHoc.DataSource = null;
                dgvKhoaHoc.DataSource = (await _khoaHocService.SearchAsync(keyword)).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Lỗi tìm kiếm",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnLamMoiKhoaHoc_Click(object sender, EventArgs e)
        {
            try
            {
                ClearForm();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Lỗi làm mới",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void dgvKhoaHoc_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
