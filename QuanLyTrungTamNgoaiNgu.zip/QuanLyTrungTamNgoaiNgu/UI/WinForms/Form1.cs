﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL.Interfaces;
using BLL.Repositories;
using Entities;
using System.Configuration;

namespace WinForms
{
    public partial class Form1 : Form
    {
        private readonly ILoginService _loginService;
        public Form1()
        {
            InitializeComponent();

            // ✅ TRUYỀN XUỐNG BLL
            _loginService = new LoginService();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string user = txtTenDangNhap.Text.Trim();
            string pass = txtMatKhau.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }

            TaiKhoan tk = _loginService.DangNhap(user, pass);

            if (tk == null)
            {
                MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu");
                return;
            }

            // Mở MainUI
            MainUI mainForm = new MainUI();
            mainForm.Text = $"Chào {tk.TenDangNhap} ({tk.Quyen})"; // có thể truyền tên người dùng
            mainForm.Show();

            // Ẩn Form1 để người dùng không thể tương tác lại
            //this.Hide();



        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
