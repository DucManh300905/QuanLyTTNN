﻿using BLL.Interfaces;
using BLL.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class DangKyUI : Form
    {
        private readonly IKhoaHocService _khoaHocService;
        private readonly IDangKyService _dangKyService;
        public DangKyUI()
        {
            InitializeComponent();
            _khoaHocService = new KhoaHocService();
            _dangKyService = new DangKyService();



            dgvCourses.CellValueChanged += dgvCourses_CellValueChanged;
            dgvCourses.CurrentCellDirtyStateChanged += dgvCourses_CurrentCellDirtyStateChanged;
        }

        private void DangKyUI_Load(object sender, EventArgs e)
        {
            LoadDanhSachKhoaHoc();
        }
        private void LoadDanhSachKhoaHoc()
        {
            dgvCourses.Rows.Clear();

            var khoaHocs = _khoaHocService.GetAll();

            foreach (var kh in khoaHocs)
            {
                dgvCourses.Rows.Add(
                    false,                 // colSelect
                    kh.MaKhoaHoc,          // colCourseID (ẩn)
                    kh.MaKhoaHoc,          // colMaKH
                    kh.TenKhoaHoc,         // colCourseName
                    kh.TrinhDo,            // colTrinhDo
                    kh.SoBuoi,             // colSoBuoi
                    kh.HocPhi.ToString("N0"), // colPrice
                    kh.ThoiLuong           // colThoiLuong
                );


            }
        }

        private void dgvCourses_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvCourses.IsCurrentCellDirty)
            {
                dgvCourses.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgvCourses_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dgvCourses.Columns[e.ColumnIndex].Name == "colSelect")
            {
                UpdateSelectedCoursesAndTotal();
            }
        }
        private void UpdateSelectedCoursesAndTotal()
        {
            lstSelectedCourses.Items.Clear();
            decimal total = 0;

            foreach (DataGridViewRow row in dgvCourses.Rows)
            {
                if (row.Cells["colSelect"].Value != null &&
                    Convert.ToBoolean(row.Cells["colSelect"].Value))
                {
                    string tenKH = row.Cells["colCourseName"].Value.ToString();

                    decimal hocPhi = Convert.ToDecimal(
                        row.Cells["colPrice"].Value.ToString().Replace(",", "")
                    );

                    lstSelectedCourses.Items.Add($"{tenKH} - {hocPhi:N0} VNĐ");
                    total += hocPhi;
                }
            }

            txtTotalAmount.Text = $"{total:N0} VNĐ";
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string maHocVien = txtMaHocVien.Text.Trim();
                string tenHocVien = txtName.Text.Trim();
                if (string.IsNullOrEmpty(maHocVien))
                {
                    MessageBox.Show("Vui lòng nhập mã học viên");
                    return;
                }

                // ===== LẤY DANH SÁCH KHÓA HỌC ĐÃ CHỌN =====
                List<string> maKhoaHocs = new List<string>();

                foreach (DataGridViewRow row in dgvCourses.Rows)
                {
                    if (row.Cells["colSelect"].Value != null &&
                        Convert.ToBoolean(row.Cells["colSelect"].Value))
                    {
                        string maKH = row.Cells["colMaKH"].Value.ToString();
                        maKhoaHocs.Add(maKH);
                    }
                }

                // ===== GỌI SERVICE =====
                _dangKyService.DangKyKhoaHoc(
                    maHocVien,
                    tenHocVien,
                    maKhoaHocs
                );

                MessageBox.Show(
                    "Đăng ký khóa học thành công!",
                    "Thành công",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                ResetForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Lỗi đăng ký",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
        private void ResetForm()
        {
            txtMaHocVien.Clear();
            txtName.Clear();
            txtTotalAmount.Text = "0 VNĐ";
            lstSelectedCourses.Items.Clear();

            foreach (DataGridViewRow row in dgvCourses.Rows)
            {
                row.Cells["colSelect"].Value = false;
            }
        }

    }
}
