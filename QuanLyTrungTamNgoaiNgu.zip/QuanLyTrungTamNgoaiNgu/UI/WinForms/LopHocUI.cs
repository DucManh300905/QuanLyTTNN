﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL.Interfaces;
using BLL.Repositories;
using Entities;
using BLL.Factory;

namespace WinForms
{
    public partial class LopHocUI : Form
    {
        private readonly ILopHocService _lopHocService;
        private readonly IKhoaHocService _khoaHocService;
        private readonly IGiaoVienService _giaoVienService;
        private readonly ILopHocDetailService _lopHocDetailService;

        public LopHocUI()
        {
            InitializeComponent();
            flowLayoutPanel1.Tag = "CARD_TEMPLATE";
            flowLayoutPanel1.Visible = false;

            _lopHocService = new LopHocService();
            _khoaHocService = new KhoaHocService();
            _giaoVienService = new GiaoVienService();
            _lopHocDetailService = BLL.Factory.ServiceFactory.GetLopHocDetailService();

            // Các service cũ của bạn cũng nên sửa lại theo cách này nếu muốn chuẩn 100%
            _lopHocService = new LopHocService();
        }

        private void LoadComboKhoaHoc()
        {
            var dsKhoaHoc = _khoaHocService.GetAll().ToList();
            cboKhoaHoc.DataSource = dsKhoaHoc;
            cboKhoaHoc.DisplayMember = "TenKhoaHoc";
            cboKhoaHoc.ValueMember = "MaKhoaHoc";
            cboKhoaHoc.SelectedIndex = -1;
        }

        private void LoadComboGiaoVien()
        {
            var dsGV = _giaoVienService.GetAll().ToList();
            cboGiaoVien.DataSource = dsGV;
            cboGiaoVien.DisplayMember = "HoTen";
            cboGiaoVien.ValueMember = "MaGV";
            cboGiaoVien.SelectedIndex = -1;
        }

        private void LopHocUI_Load(object sender, EventArgs e)
        {
            LoadComboKhoaHoc();
            LoadComboGiaoVien();
            TaiDanhSachLopHoc();
        }

        private Panel TaoCardLopHoc(string maLop, string tenlop, string khoaHoc, string maGV, int siSo, string phong)
        {
            // Panel chính với border radius effect
            Panel cardContainer = new Panel
            {
                Width = 320,
                Height = 180,
                Margin = new Padding(15),
                BackColor = Color.White,
                Cursor = Cursors.Hand,
                Tag = maLop
            };

            // Panel header với màu gradient effect
            Panel headerPanel = new Panel
            {
                Width = 320,
                Height = 50,
                BackColor = Color.FromArgb(52, 152, 219), // Màu xanh dương đẹp
                Dock = DockStyle.Top
            };

            Label lblMaLop = new Label
            {
                Text = maLop,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(15, 8)
            };

            Label lblTenLop = new Label
            {
                Text = tenlop,
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(15, 28)
            };

            headerPanel.Controls.Add(lblMaLop);
            headerPanel.Controls.Add(lblTenLop);

            // Panel body với thông tin chi tiết
            Panel bodyPanel = new Panel
            {
                Width = 320,
                Height = 130,
                BackColor = Color.White,
                Dock = DockStyle.Fill,
                Padding = new Padding(15, 10, 15, 10)
            };

            // Icon và text cho từng thông tin
            int yPos = 10;

            Label lblKhoa = new Label
            {
                Text = $"📚 Khóa học: {khoaHoc}",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(52, 73, 94),
                AutoSize = true,
                Location = new Point(15, yPos)
            };
            yPos += 25;

            Label lblGV = new Label
            {
                Text = $"👨‍🏫 Giáo viên: {maGV}",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(52, 73, 94),
                AutoSize = true,
                Location = new Point(15, yPos)
            };
            yPos += 25;

            Label lblSiSo = new Label
            {
                Text = $"👥 Sĩ số: {siSo} học viên",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(52, 73, 94),
                AutoSize = true,
                Location = new Point(15, yPos)
            };
            yPos += 25;

            Label lblPhong = new Label
            {
                Text = $"🏫 Phòng: {phong}",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(52, 73, 94),
                AutoSize = true,
                Location = new Point(15, yPos)
            };

            bodyPanel.Controls.Add(lblKhoa);
            bodyPanel.Controls.Add(lblGV);
            bodyPanel.Controls.Add(lblSiSo);
            bodyPanel.Controls.Add(lblPhong);

            cardContainer.Controls.Add(headerPanel);
            cardContainer.Controls.Add(bodyPanel);

            // Thêm border shadow effect
            cardContainer.Paint += (s, e) =>
            {
                ControlPaint.DrawBorder(e.Graphics, cardContainer.ClientRectangle,
                    Color.FromArgb(189, 195, 199), 1, ButtonBorderStyle.Solid,
                    Color.FromArgb(189, 195, 199), 1, ButtonBorderStyle.Solid,
                    Color.FromArgb(189, 195, 199), 1, ButtonBorderStyle.Solid,
                    Color.FromArgb(189, 195, 199), 1, ButtonBorderStyle.Solid);
            };

            // Hiệu ứng hover
            Color originalColor = headerPanel.BackColor;
            cardContainer.MouseEnter += (s, e) =>
            {
                headerPanel.BackColor = Color.FromArgb(41, 128, 185); // Màu đậm hơn khi hover
                cardContainer.BackColor = Color.FromArgb(236, 240, 241);
            };

            cardContainer.MouseLeave += (s, e) =>
            {
                headerPanel.BackColor = originalColor;
                cardContainer.BackColor = Color.White;
            };

            // Click card → load lên form
            Action<object, EventArgs> clickHandler = (s, ev) =>
            {
                txtMaLop.Text = maLop;
                txtTenLop.Text = tenlop;
                cboKhoaHoc.SelectedValue = khoaHoc;
                cboGiaoVien.SelectedValue = maGV;
                txtMaLop.Enabled = false;
                txtSiSoToiDa.Text = siSo.ToString();
                txtPhongHoc.Text = phong;
            };

            cardContainer.Click += new EventHandler(clickHandler);
            headerPanel.Click += new EventHandler(clickHandler);
            bodyPanel.Click += new EventHandler(clickHandler);
            foreach (Control ctrl in headerPanel.Controls)
                ctrl.Click += new EventHandler(clickHandler);
            foreach (Control ctrl in bodyPanel.Controls)
                ctrl.Click += new EventHandler(clickHandler);

            // Double click để xem chi tiết
            Action<object, EventArgs> doubleClickHandler = (s, ev) =>
            {
                // 1. Khởi tạo Form Detail
                LopHocDetailUI formDetail = new LopHocDetailUI(maLop, tenlop, khoaHoc, maGV, siSo, phong);

                // 2. TRUYỀN SERVICE SANG (Gán vào Property của form con)
                formDetail.LopHocDetailService = this._lopHocDetailService;

                formDetail.ShowDialog();
            };

            cardContainer.DoubleClick += new EventHandler(doubleClickHandler);
            headerPanel.DoubleClick += new EventHandler(doubleClickHandler);
            bodyPanel.DoubleClick += new EventHandler(doubleClickHandler);

            return cardContainer;
        }

        private void TaiDanhSachLopHoc()
        {
            flowLayoutPanelLopHoc.Controls.Clear();

            // Cấu hình FlowLayoutPanel để đẹp hơn
            flowLayoutPanelLopHoc.AutoScroll = true;
            flowLayoutPanelLopHoc.WrapContents = true;
            flowLayoutPanelLopHoc.Padding = new Padding(10);
            flowLayoutPanelLopHoc.BackColor = Color.FromArgb(236, 240, 241); // Màu nền xám nhạt

            var dsLop = _lopHocService.GetAll();

            foreach (var lop in dsLop)
            {
                var card = TaoCardLopHoc(
                    lop.MaLop,
                    lop.TenLop,
                    lop.MaKhoaHoc,
                    lop.MaGV.ToString(),
                    lop.SiSoToiDa,
                    lop.PhongHoc
                );

                flowLayoutPanelLopHoc.Controls.Add(card);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                var lop = new LopHoc
                {
                    MaLop = txtMaLop.Text.Trim(),
                    TenLop = txtTenLop.Text.Trim(),
                    MaKhoaHoc = cboKhoaHoc.SelectedValue.ToString(),
                    MaGV = cboGiaoVien.SelectedValue.ToString(),
                    SiSoToiDa = int.Parse(txtSiSoToiDa.Text),
                    PhongHoc = txtPhongHoc.Text.Trim()
                };

                _lopHocService.Add(lop);
                TaiDanhSachLopHoc();
                LamMoiForm();
                MessageBox.Show("Tạo lớp thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LamMoiForm()
        {
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtSiSoToiDa.Clear();
            txtPhongHoc.Clear();
            cboKhoaHoc.SelectedIndex = -1;
            cboGiaoVien.SelectedIndex = -1;
            txtMaLop.Enabled = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboGiaoVien.SelectedValue == null || cboKhoaHoc.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn đầy đủ khóa học và giáo viên", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var lop = new LopHoc
                {
                    MaLop = txtMaLop.Text.Trim(),
                    TenLop = txtTenLop.Text.Trim(),
                    MaKhoaHoc = cboKhoaHoc.SelectedValue.ToString(),
                    MaGV = cboGiaoVien.SelectedValue.ToString(),
                    SiSoToiDa = int.Parse(txtSiSoToiDa.Text),
                    PhongHoc = txtPhongHoc.Text.Trim()
                };

                _lopHocService.Update(lop);
                TaiDanhSachLopHoc();
                MessageBox.Show("Cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Sĩ số phải là số", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaLop.Text)) return;

            var ok = MessageBox.Show("Bạn có chắc chắn muốn xóa lớp học này?", "Xác nhận xóa",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (ok == DialogResult.No) return;

            _lopHocService.Delete(txtMaLop.Text.Trim());
            TaiDanhSachLopHoc();
            LamMoiForm();
            MessageBox.Show("Xóa lớp học thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LamMoiForm();
        }

        private async void btnTimKiem_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtTimKiem.Text.Trim();

                flowLayoutPanelLopHoc.Controls.Clear();

                var dsLop = await _lopHocService.SearchAsync(keyword);

                if (!dsLop.Any())
                {
                    MessageBox.Show("Không tìm thấy lớp học phù hợp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiDanhSachLopHoc(); // Load lại danh sách ban đầu
                    return;
                }

                foreach (var lop in dsLop)
                {
                    var card = TaoCardLopHoc(
                        lop.MaLop,
                        lop.TenLop,
                        lop.MaKhoaHoc,
                        lop.MaGV,
                        lop.SiSoToiDa,
                        lop.PhongHoc
                    );

                    flowLayoutPanelLopHoc.Controls.Add(card);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tìm kiếm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}