﻿using BLL.Interfaces;
using BLL.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entities;

namespace WinForms
{
    public partial class HocVienUI : Form
    {
        private readonly IHocVienService _hocVienService;
        public HocVienUI()
        {
            InitializeComponent();
            _hocVienService = new HocVienService(); // ✅
        }

        private void HocVienUI_Load(object sender, EventArgs e)
        {
            LoadData();

        }
        private void LoadData()
        {
            dgvHocVien.AutoGenerateColumns = false;
            dgvHocVien.DataSource = _hocVienService.GetAll().ToList();
        }

        private HocVien GetHocVienFromForm()
        {
            return new HocVien
            {
                MaHocVien = txtMaHocVien.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                GioiTinh = cboGioiTinh.Text,
                NgaySinh = dtpNgaySinh.Value,
                Email = txtEmail.Text.Trim(),
                SoDienThoai = txtSoDienThoai.Text.Trim(),
                CCCD = txtCCCD.Text.Trim()
            };
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                HocVien hv = GetHocVienFromForm();
                _hocVienService.Add(hv);
                MessageBox.Show("Thêm học viên thành công");
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                HocVien hv = GetHocVienFromForm();
                _hocVienService.Update(hv);
                MessageBox.Show("Cập nhật thành công");
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHocVien.Text))
            {
                MessageBox.Show("Chọn học viên cần xóa");
                return;
            }

            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _hocVienService.Delete(txtMaHocVien.Text.Trim());
                LoadData();
            }
        }

        private void dgvHocVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvHocVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvHocVien.Rows[e.RowIndex];

            txtMaHocVien.Text = row.Cells["colMaSV"].Value?.ToString();
            txtHoTen.Text = row.Cells["colHoTen"].Value?.ToString();
            cboGioiTinh.Text = row.Cells["colGioiTinh"].Value?.ToString();
            dtpNgaySinh.Value = Convert.ToDateTime(row.Cells["colNgaySinh"].Value);
            txtEmail.Text = row.Cells["colEmail"].Value?.ToString();
            txtSoDienThoai.Text = row.Cells["colSoDienThoai"].Value?.ToString();
            txtCCCD.Text = row.Cells["colCCCD"].Value?.ToString();

            txtMaHocVien.ReadOnly = true;
        }

        private async void btnTimKiem_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim();

            if (string.IsNullOrEmpty(keyword))
            {
                LoadData();
                return;
            }

            var data = await _hocVienService.SearchAsync(keyword);
            dgvHocVien.DataSource = data.ToList();
        }
        private void ClearForm()
        {
            txtMaHocVien.Clear();
            txtHoTen.Clear();
            txtEmail.Clear();
            txtSoDienThoai.Clear();
            txtCCCD.Clear();
            txtTimKiem.Clear();

            cboGioiTinh.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;
            txtMaHocVien.ReadOnly = false; // 🔓 MỞ LẠI
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            ClearForm();
            LoadData();

        }

        private void txtMaHocVien_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
