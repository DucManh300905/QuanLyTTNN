﻿namespace WinForms
{
    partial class KhoaHocUI
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.lblTrinhDo = new System.Windows.Forms.Label();
            this.txtTrinhDo = new System.Windows.Forms.TextBox();
            this.lblSoBuoiHoc = new System.Windows.Forms.Label();
            this.txtSoBuoiHoc = new System.Windows.Forms.TextBox();
            this.lblThoiLuong = new System.Windows.Forms.Label();
            this.txtThoiLuong = new System.Windows.Forms.TextBox();
            this.lblHocPhi = new System.Windows.Forms.Label();
            this.txtHocPhi = new System.Windows.Forms.TextBox();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.dgvKhoaHoc = new System.Windows.Forms.DataGridView();
            this.colMaKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrinhDo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoBuoiHoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThoiLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThemKH = new System.Windows.Forms.Button();
            this.btnXoaKH = new System.Windows.Forms.Button();
            this.btnSuaKH = new System.Windows.Forms.Button();
            this.btnLamMoiKhoaHoc = new System.Windows.Forms.Button();
            this.pnlTop.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.pnlRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoaHoc)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.pnlTop.Controls.Add(this.lblTitle);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1000, 70);
            this.pnlTop.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(1000, 70);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ KHÓA HỌC";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlLeft
            // 
            this.pnlLeft.AutoScroll = true;
            this.pnlLeft.BackColor = System.Drawing.Color.White;
            this.pnlLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLeft.Controls.Add(this.lblMaKH);
            this.pnlLeft.Controls.Add(this.txtMaKH);
            this.pnlLeft.Controls.Add(this.lblTenKH);
            this.pnlLeft.Controls.Add(this.txtTenKH);
            this.pnlLeft.Controls.Add(this.lblTrinhDo);
            this.pnlLeft.Controls.Add(this.txtTrinhDo);
            this.pnlLeft.Controls.Add(this.lblSoBuoiHoc);
            this.pnlLeft.Controls.Add(this.txtSoBuoiHoc);
            this.pnlLeft.Controls.Add(this.lblThoiLuong);
            this.pnlLeft.Controls.Add(this.txtThoiLuong);
            this.pnlLeft.Controls.Add(this.lblHocPhi);
            this.pnlLeft.Controls.Add(this.txtHocPhi);
            this.pnlLeft.Location = new System.Drawing.Point(15, 85);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(350, 444);
            this.pnlLeft.TabIndex = 1;
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblMaKH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblMaKH.Location = new System.Drawing.Point(15, 20);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(99, 19);
            this.lblMaKH.TabIndex = 0;
            this.lblMaKH.Text = "Mã khóa học:";
            // 
            // txtMaKH
            // 
            this.txtMaKH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMaKH.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtMaKH.Location = new System.Drawing.Point(15, 45);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(318, 25);
            this.txtMaKH.TabIndex = 1;
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTenKH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblTenKH.Location = new System.Drawing.Point(15, 85);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(101, 19);
            this.lblTenKH.TabIndex = 2;
            this.lblTenKH.Text = "Tên khóa học:";
            // 
            // txtTenKH
            // 
            this.txtTenKH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTenKH.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTenKH.Location = new System.Drawing.Point(15, 110);
            this.txtTenKH.Multiline = true;
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(318, 50);
            this.txtTenKH.TabIndex = 3;
            // 
            // lblTrinhDo
            // 
            this.lblTrinhDo.AutoSize = true;
            this.lblTrinhDo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTrinhDo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblTrinhDo.Location = new System.Drawing.Point(15, 175);
            this.lblTrinhDo.Name = "lblTrinhDo";
            this.lblTrinhDo.Size = new System.Drawing.Size(68, 19);
            this.lblTrinhDo.TabIndex = 4;
            this.lblTrinhDo.Text = "Trình độ:";
            // 
            // txtTrinhDo
            // 
            this.txtTrinhDo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTrinhDo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTrinhDo.Location = new System.Drawing.Point(15, 200);
            this.txtTrinhDo.Name = "txtTrinhDo";
            this.txtTrinhDo.Size = new System.Drawing.Size(318, 25);
            this.txtTrinhDo.TabIndex = 5;
            // 
            // lblSoBuoiHoc
            // 
            this.lblSoBuoiHoc.AutoSize = true;
            this.lblSoBuoiHoc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblSoBuoiHoc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblSoBuoiHoc.Location = new System.Drawing.Point(15, 240);
            this.lblSoBuoiHoc.Name = "lblSoBuoiHoc";
            this.lblSoBuoiHoc.Size = new System.Drawing.Size(92, 19);
            this.lblSoBuoiHoc.TabIndex = 6;
            this.lblSoBuoiHoc.Text = "Số buổi học:";
            // 
            // txtSoBuoiHoc
            // 
            this.txtSoBuoiHoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSoBuoiHoc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSoBuoiHoc.Location = new System.Drawing.Point(15, 265);
            this.txtSoBuoiHoc.Name = "txtSoBuoiHoc";
            this.txtSoBuoiHoc.Size = new System.Drawing.Size(318, 25);
            this.txtSoBuoiHoc.TabIndex = 7;
            // 
            // lblThoiLuong
            // 
            this.lblThoiLuong.AutoSize = true;
            this.lblThoiLuong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblThoiLuong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblThoiLuong.Location = new System.Drawing.Point(15, 305);
            this.lblThoiLuong.Name = "lblThoiLuong";
            this.lblThoiLuong.Size = new System.Drawing.Size(121, 19);
            this.lblThoiLuong.TabIndex = 8;
            this.lblThoiLuong.Text = "Thời lượng (giờ):";
            // 
            // txtThoiLuong
            // 
            this.txtThoiLuong.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtThoiLuong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtThoiLuong.Location = new System.Drawing.Point(15, 330);
            this.txtThoiLuong.Name = "txtThoiLuong";
            this.txtThoiLuong.Size = new System.Drawing.Size(318, 25);
            this.txtThoiLuong.TabIndex = 9;
            // 
            // lblHocPhi
            // 
            this.lblHocPhi.AutoSize = true;
            this.lblHocPhi.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblHocPhi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblHocPhi.Location = new System.Drawing.Point(15, 370);
            this.lblHocPhi.Name = "lblHocPhi";
            this.lblHocPhi.Size = new System.Drawing.Size(109, 19);
            this.lblHocPhi.TabIndex = 10;
            this.lblHocPhi.Text = "Học phí (VNĐ):";
            // 
            // txtHocPhi
            // 
            this.txtHocPhi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHocPhi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtHocPhi.Location = new System.Drawing.Point(15, 395);
            this.txtHocPhi.Name = "txtHocPhi";
            this.txtHocPhi.Size = new System.Drawing.Size(318, 25);
            this.txtHocPhi.TabIndex = 11;
            // 
            // pnlRight
            // 
            this.pnlRight.BackColor = System.Drawing.Color.White;
            this.pnlRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRight.Controls.Add(this.lblTimKiem);
            this.pnlRight.Controls.Add(this.txtTimKiem);
            this.pnlRight.Controls.Add(this.btnTimKiem);
            this.pnlRight.Controls.Add(this.dgvKhoaHoc);
            this.pnlRight.Location = new System.Drawing.Point(380, 151);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Size = new System.Drawing.Size(605, 378);
            this.pnlRight.TabIndex = 2;
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.AutoSize = true;
            this.lblTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblTimKiem.Location = new System.Drawing.Point(15, 15);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(75, 19);
            this.lblTimKiem.TabIndex = 0;
            this.lblTimKiem.Text = "Tìm kiếm:";
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimKiem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtTimKiem.Location = new System.Drawing.Point(15, 40);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(440, 27);
            this.txtTimKiem.TabIndex = 1;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnTimKiem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTimKiem.FlatAppearance.BorderSize = 0;
            this.btnTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTimKiem.ForeColor = System.Drawing.Color.White;
            this.btnTimKiem.Location = new System.Drawing.Point(465, 35);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(120, 35);
            this.btnTimKiem.TabIndex = 2;
            this.btnTimKiem.Text = "🔍 TÌM KIẾM";
            this.btnTimKiem.UseVisualStyleBackColor = false;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // dgvKhoaHoc
            // 
            this.dgvKhoaHoc.AllowUserToAddRows = false;
            this.dgvKhoaHoc.AllowUserToDeleteRows = false;
            this.dgvKhoaHoc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhoaHoc.BackgroundColor = System.Drawing.Color.White;
            this.dgvKhoaHoc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvKhoaHoc.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvKhoaHoc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvKhoaHoc.ColumnHeadersHeight = 40;
            this.dgvKhoaHoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvKhoaHoc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaKH,
            this.colTenKH,
            this.colTrinhDo,
            this.colSoBuoiHoc,
            this.colThoiLuong,
            this.colHocPhi});
            this.dgvKhoaHoc.EnableHeadersVisualStyles = false;
            this.dgvKhoaHoc.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(195)))), ((int)(((byte)(199)))));
            this.dgvKhoaHoc.Location = new System.Drawing.Point(3, 85);
            this.dgvKhoaHoc.Name = "dgvKhoaHoc";
            this.dgvKhoaHoc.ReadOnly = true;
            this.dgvKhoaHoc.RowHeadersVisible = false;
            this.dgvKhoaHoc.RowTemplate.Height = 35;
            this.dgvKhoaHoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKhoaHoc.Size = new System.Drawing.Size(597, 269);
            this.dgvKhoaHoc.TabIndex = 3;
            this.dgvKhoaHoc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKhoaHoc_CellClick);
            this.dgvKhoaHoc.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKhoaHoc_CellValueChanged);
            // 
            // colMaKH
            // 
            this.colMaKH.DataPropertyName = "MaKhoaHoc";
            this.colMaKH.HeaderText = "Mã KH";
            this.colMaKH.Name = "colMaKH";
            this.colMaKH.ReadOnly = true;
            // 
            // colTenKH
            // 
            this.colTenKH.DataPropertyName = "TenKhoaHoc";
            this.colTenKH.HeaderText = "Tên khóa học";
            this.colTenKH.Name = "colTenKH";
            this.colTenKH.ReadOnly = true;
            // 
            // colTrinhDo
            // 
            this.colTrinhDo.DataPropertyName = "TrinhDo";
            this.colTrinhDo.HeaderText = "Trình độ";
            this.colTrinhDo.Name = "colTrinhDo";
            this.colTrinhDo.ReadOnly = true;
            // 
            // colSoBuoiHoc
            // 
            this.colSoBuoiHoc.DataPropertyName = "SoBuoi";
            this.colSoBuoiHoc.HeaderText = "Số buổi";
            this.colSoBuoiHoc.Name = "colSoBuoiHoc";
            this.colSoBuoiHoc.ReadOnly = true;
            // 
            // colThoiLuong
            // 
            this.colThoiLuong.DataPropertyName = "ThoiLuong";
            this.colThoiLuong.HeaderText = "Thời lượng";
            this.colThoiLuong.Name = "colThoiLuong";
            this.colThoiLuong.ReadOnly = true;
            // 
            // colHocPhi
            // 
            this.colHocPhi.DataPropertyName = "HocPhi";
            this.colHocPhi.HeaderText = "Học phí";
            this.colHocPhi.Name = "colHocPhi";
            this.colHocPhi.ReadOnly = true;
            // 
            // btnThemKH
            // 
            this.btnThemKH.BackColor = System.Drawing.Color.Fuchsia;
            this.btnThemKH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThemKH.FlatAppearance.BorderSize = 0;
            this.btnThemKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemKH.ForeColor = System.Drawing.Color.White;
            this.btnThemKH.Location = new System.Drawing.Point(382, 85);
            this.btnThemKH.Name = "btnThemKH";
            this.btnThemKH.Size = new System.Drawing.Size(120, 35);
            this.btnThemKH.TabIndex = 4;
            this.btnThemKH.Text = "THÊM";
            this.btnThemKH.UseVisualStyleBackColor = false;
            this.btnThemKH.Click += new System.EventHandler(this.btnThemKH_Click);
            // 
            // btnXoaKH
            // 
            this.btnXoaKH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnXoaKH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXoaKH.FlatAppearance.BorderSize = 0;
            this.btnXoaKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoaKH.ForeColor = System.Drawing.Color.White;
            this.btnXoaKH.Location = new System.Drawing.Point(660, 85);
            this.btnXoaKH.Name = "btnXoaKH";
            this.btnXoaKH.Size = new System.Drawing.Size(120, 35);
            this.btnXoaKH.TabIndex = 5;
            this.btnXoaKH.Text = "XÓA";
            this.btnXoaKH.UseVisualStyleBackColor = false;
            this.btnXoaKH.Click += new System.EventHandler(this.btnXoaKH_Click);
            // 
            // btnSuaKH
            // 
            this.btnSuaKH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSuaKH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSuaKH.FlatAppearance.BorderSize = 0;
            this.btnSuaKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSuaKH.ForeColor = System.Drawing.Color.White;
            this.btnSuaKH.Location = new System.Drawing.Point(521, 85);
            this.btnSuaKH.Name = "btnSuaKH";
            this.btnSuaKH.Size = new System.Drawing.Size(120, 35);
            this.btnSuaKH.TabIndex = 6;
            this.btnSuaKH.Text = "SỨA";
            this.btnSuaKH.UseVisualStyleBackColor = false;
            this.btnSuaKH.Click += new System.EventHandler(this.btnSuaKH_Click);
            // 
            // btnLamMoiKhoaHoc
            // 
            this.btnLamMoiKhoaHoc.BackColor = System.Drawing.Color.Silver;
            this.btnLamMoiKhoaHoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLamMoiKhoaHoc.FlatAppearance.BorderSize = 0;
            this.btnLamMoiKhoaHoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLamMoiKhoaHoc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLamMoiKhoaHoc.ForeColor = System.Drawing.Color.White;
            this.btnLamMoiKhoaHoc.Location = new System.Drawing.Point(799, 85);
            this.btnLamMoiKhoaHoc.Name = "btnLamMoiKhoaHoc";
            this.btnLamMoiKhoaHoc.Size = new System.Drawing.Size(120, 35);
            this.btnLamMoiKhoaHoc.TabIndex = 7;
            this.btnLamMoiKhoaHoc.Text = "LÀM MỚI";
            this.btnLamMoiKhoaHoc.UseVisualStyleBackColor = false;
            this.btnLamMoiKhoaHoc.Click += new System.EventHandler(this.btnLamMoiKhoaHoc_Click);
            // 
            // KhoaHocUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(1000, 548);
            this.Controls.Add(this.btnLamMoiKhoaHoc);
            this.Controls.Add(this.btnSuaKH);
            this.Controls.Add(this.btnXoaKH);
            this.Controls.Add(this.btnThemKH);
            this.Controls.Add(this.pnlRight);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.pnlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "KhoaHocUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý khóa học";
            this.Load += new System.EventHandler(this.KhoaHocUI_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoaHoc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.Label lblTrinhDo;
        private System.Windows.Forms.TextBox txtTrinhDo;
        private System.Windows.Forms.Label lblSoBuoiHoc;
        private System.Windows.Forms.TextBox txtSoBuoiHoc;
        private System.Windows.Forms.Label lblThoiLuong;
        private System.Windows.Forms.TextBox txtThoiLuong;
        private System.Windows.Forms.Label lblHocPhi;
        private System.Windows.Forms.TextBox txtHocPhi;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Label lblTimKiem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.DataGridView dgvKhoaHoc;
        private System.Windows.Forms.Button btnThemKH;
        private System.Windows.Forms.Button btnXoaKH;
        private System.Windows.Forms.Button btnSuaKH;
        private System.Windows.Forms.Button btnLamMoiKhoaHoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrinhDo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoBuoiHoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThoiLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHocPhi;
    }
}