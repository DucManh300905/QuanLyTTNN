﻿namespace WinForms
{
    partial class DangKyUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelStudentInfo = new System.Windows.Forms.Panel();
            this.lblStudentInfo = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblMaHocVien = new System.Windows.Forms.Label();
            this.txtMaHocVien = new System.Windows.Forms.TextBox();
            this.panelCourses = new System.Windows.Forms.Panel();
            this.lblCourseList = new System.Windows.Forms.Label();
            this.dgvCourses = new System.Windows.Forms.DataGridView();
            this.panelSummary = new System.Windows.Forms.Panel();
            this.lblSelectedCourses = new System.Windows.Forms.Label();
            this.lstSelectedCourses = new System.Windows.Forms.ListBox();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnPrintInvoice = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.colSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCourseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCourseName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrinhDo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoBuoi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThoiLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelHeader.SuspendLayout();
            this.panelStudentInfo.SuspendLayout();
            this.panelCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).BeginInit();
            this.panelSummary.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1104, 60);
            this.panelHeader.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(350, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(257, 32);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "ĐĂNG KÝ KHÓA HỌC";
            // 
            // panelStudentInfo
            // 
            this.panelStudentInfo.BackColor = System.Drawing.Color.White;
            this.panelStudentInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStudentInfo.Controls.Add(this.lblStudentInfo);
            this.panelStudentInfo.Controls.Add(this.lblName);
            this.panelStudentInfo.Controls.Add(this.txtName);
            this.panelStudentInfo.Controls.Add(this.lblMaHocVien);
            this.panelStudentInfo.Controls.Add(this.txtMaHocVien);
            this.panelStudentInfo.Location = new System.Drawing.Point(20, 80);
            this.panelStudentInfo.Name = "panelStudentInfo";
            this.panelStudentInfo.Size = new System.Drawing.Size(749, 120);
            this.panelStudentInfo.TabIndex = 1;
            // 
            // lblStudentInfo
            // 
            this.lblStudentInfo.AutoSize = true;
            this.lblStudentInfo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblStudentInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.lblStudentInfo.Location = new System.Drawing.Point(10, 10);
            this.lblStudentInfo.Name = "lblStudentInfo";
            this.lblStudentInfo.Size = new System.Drawing.Size(153, 21);
            this.lblStudentInfo.TabIndex = 0;
            this.lblStudentInfo.Text = "Thông tin học viên";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblName.Location = new System.Drawing.Point(331, 48);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(54, 19);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Họ tên:";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtName.Location = new System.Drawing.Point(335, 70);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(280, 25);
            this.txtName.TabIndex = 2;
            // 
            // lblMaHocVien
            // 
            this.lblMaHocVien.AutoSize = true;
            this.lblMaHocVien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblMaHocVien.Location = new System.Drawing.Point(10, 48);
            this.lblMaHocVien.Name = "lblMaHocVien";
            this.lblMaHocVien.Size = new System.Drawing.Size(87, 19);
            this.lblMaHocVien.TabIndex = 5;
            this.lblMaHocVien.Text = "Mã học viên:";
            // 
            // txtMaHocVien
            // 
            this.txtMaHocVien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtMaHocVien.Location = new System.Drawing.Point(14, 70);
            this.txtMaHocVien.Name = "txtMaHocVien";
            this.txtMaHocVien.Size = new System.Drawing.Size(280, 25);
            this.txtMaHocVien.TabIndex = 6;
            // 
            // panelCourses
            // 
            this.panelCourses.BackColor = System.Drawing.Color.White;
            this.panelCourses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCourses.Controls.Add(this.lblCourseList);
            this.panelCourses.Controls.Add(this.dgvCourses);
            this.panelCourses.Location = new System.Drawing.Point(20, 220);
            this.panelCourses.Name = "panelCourses";
            this.panelCourses.Size = new System.Drawing.Size(749, 350);
            this.panelCourses.TabIndex = 2;
            // 
            // lblCourseList
            // 
            this.lblCourseList.AutoSize = true;
            this.lblCourseList.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblCourseList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.lblCourseList.Location = new System.Drawing.Point(10, 10);
            this.lblCourseList.Name = "lblCourseList";
            this.lblCourseList.Size = new System.Drawing.Size(163, 21);
            this.lblCourseList.TabIndex = 0;
            this.lblCourseList.Text = "Danh sách khóa học";
            // 
            // dgvCourses
            // 
            this.dgvCourses.AllowUserToAddRows = false;
            this.dgvCourses.AllowUserToDeleteRows = false;
            this.dgvCourses.BackgroundColor = System.Drawing.Color.White;
            this.dgvCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCourses.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSelect,
            this.colCourseID,
            this.colMaKH,
            this.colCourseName,
            this.colTrinhDo,
            this.colSoBuoi,
            this.colPrice,
            this.colThoiLuong});
            this.dgvCourses.Location = new System.Drawing.Point(14, 45);
            this.dgvCourses.Name = "dgvCourses";
            this.dgvCourses.RowHeadersWidth = 25;
            this.dgvCourses.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCourses.Size = new System.Drawing.Size(716, 290);
            this.dgvCourses.TabIndex = 1;
            this.dgvCourses.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCourses_CellValueChanged);
            this.dgvCourses.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvCourses_CurrentCellDirtyStateChanged);
            // 
            // panelSummary
            // 
            this.panelSummary.BackColor = System.Drawing.Color.White;
            this.panelSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSummary.Controls.Add(this.lblSelectedCourses);
            this.panelSummary.Controls.Add(this.lstSelectedCourses);
            this.panelSummary.Controls.Add(this.lblTotalAmount);
            this.panelSummary.Controls.Add(this.txtTotalAmount);
            this.panelSummary.Location = new System.Drawing.Point(782, 220);
            this.panelSummary.Name = "panelSummary";
            this.panelSummary.Size = new System.Drawing.Size(310, 350);
            this.panelSummary.TabIndex = 3;
            // 
            // lblSelectedCourses
            // 
            this.lblSelectedCourses.AutoSize = true;
            this.lblSelectedCourses.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblSelectedCourses.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.lblSelectedCourses.Location = new System.Drawing.Point(10, 10);
            this.lblSelectedCourses.Name = "lblSelectedCourses";
            this.lblSelectedCourses.Size = new System.Drawing.Size(146, 21);
            this.lblSelectedCourses.TabIndex = 0;
            this.lblSelectedCourses.Text = "Khóa học đã chọn";
            // 
            // lstSelectedCourses
            // 
            this.lstSelectedCourses.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstSelectedCourses.FormattingEnabled = true;
            this.lstSelectedCourses.ItemHeight = 15;
            this.lstSelectedCourses.Location = new System.Drawing.Point(10, 37);
            this.lstSelectedCourses.Name = "lstSelectedCourses";
            this.lstSelectedCourses.Size = new System.Drawing.Size(285, 244);
            this.lstSelectedCourses.TabIndex = 1;
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTotalAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.lblTotalAmount.Location = new System.Drawing.Point(10, 280);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(80, 20);
            this.lblTotalAmount.TabIndex = 2;
            this.lblTotalAmount.Text = "Tổng tiền:";
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(224)))));
            this.txtTotalAmount.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtTotalAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.txtTotalAmount.Location = new System.Drawing.Point(10, 303);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(285, 32);
            this.txtTotalAmount.TabIndex = 3;
            this.txtTotalAmount.Text = "0 VNĐ";
            this.txtTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelButtons.Controls.Add(this.btnRegister);
            this.panelButtons.Controls.Add(this.btnPrintInvoice);
            this.panelButtons.Controls.Add(this.btnReset);
            this.panelButtons.Controls.Add(this.btnExit);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelButtons.Location = new System.Drawing.Point(0, 590);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(1104, 110);
            this.panelButtons.TabIndex = 4;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnRegister.ForeColor = System.Drawing.Color.White;
            this.btnRegister.Location = new System.Drawing.Point(150, 25);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(160, 60);
            this.btnRegister.TabIndex = 0;
            this.btnRegister.Text = "Đăng ký";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnPrintInvoice
            // 
            this.btnPrintInvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnPrintInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintInvoice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnPrintInvoice.ForeColor = System.Drawing.Color.White;
            this.btnPrintInvoice.Location = new System.Drawing.Point(340, 25);
            this.btnPrintInvoice.Name = "btnPrintInvoice";
            this.btnPrintInvoice.Size = new System.Drawing.Size(160, 60);
            this.btnPrintInvoice.TabIndex = 1;
            this.btnPrintInvoice.Text = "In hóa đơn";
            this.btnPrintInvoice.UseVisualStyleBackColor = false;
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(196)))), ((int)(((byte)(15)))));
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Location = new System.Drawing.Point(530, 25);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(160, 60);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Làm mới";
            this.btnReset.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(720, 25);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(160, 60);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Thoát";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // colSelect
            // 
            this.colSelect.HeaderText = "Chọn";
            this.colSelect.Name = "colSelect";
            this.colSelect.Width = 50;
            // 
            // colCourseID
            // 
            this.colCourseID.HeaderText = "ID";
            this.colCourseID.Name = "colCourseID";
            this.colCourseID.ReadOnly = true;
            this.colCourseID.Visible = false;
            this.colCourseID.Width = 50;
            // 
            // colMaKH
            // 
            this.colMaKH.HeaderText = "Mã khóa học";
            this.colMaKH.Name = "colMaKH";
            // 
            // colCourseName
            // 
            this.colCourseName.HeaderText = "Tên khóa học";
            this.colCourseName.Name = "colCourseName";
            this.colCourseName.ReadOnly = true;
            this.colCourseName.Width = 180;
            // 
            // colTrinhDo
            // 
            this.colTrinhDo.HeaderText = "Trình Độ";
            this.colTrinhDo.Name = "colTrinhDo";
            // 
            // colSoBuoi
            // 
            this.colSoBuoi.HeaderText = "Số buổi";
            this.colSoBuoi.Name = "colSoBuoi";
            // 
            // colPrice
            // 
            this.colPrice.HeaderText = "Học phí";
            this.colPrice.Name = "colPrice";
            this.colPrice.ReadOnly = true;
            this.colPrice.Width = 110;
            // 
            // colThoiLuong
            // 
            this.colThoiLuong.HeaderText = "Thời Lượng";
            this.colThoiLuong.Name = "colThoiLuong";
            // 
            // DangKyUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(1104, 700);
            this.Controls.Add(this.panelButtons);
            this.Controls.Add(this.panelSummary);
            this.Controls.Add(this.panelCourses);
            this.Controls.Add(this.panelStudentInfo);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "DangKyUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ thống Đăng ký Khóa học";
            this.Load += new System.EventHandler(this.DangKyUI_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelStudentInfo.ResumeLayout(false);
            this.panelStudentInfo.PerformLayout();
            this.panelCourses.ResumeLayout(false);
            this.panelCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).EndInit();
            this.panelSummary.ResumeLayout(false);
            this.panelSummary.PerformLayout();
            this.panelButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelStudentInfo;
        private System.Windows.Forms.Label lblStudentInfo;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblMaHocVien;
        private System.Windows.Forms.TextBox txtMaHocVien;
        private System.Windows.Forms.Panel panelCourses;
        private System.Windows.Forms.Label lblCourseList;
        private System.Windows.Forms.Panel panelSummary;
        private System.Windows.Forms.Label lblSelectedCourses;
        private System.Windows.Forms.ListBox lstSelectedCourses;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnPrintInvoice;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgvCourses;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCourseID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCourseName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrinhDo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoBuoi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThoiLuong;
    }
}