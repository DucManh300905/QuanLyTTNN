﻿using BLL.Interfaces;
using BLL.Repositories;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class GiaoVienUI : Form
    {
        private readonly IGiaoVienService _giaovienservice;
        public GiaoVienUI()
        {
            InitializeComponent();
            _giaovienservice = new GiaoVienService();
            LoadData();
        }

        private void LoadData()
        {
            dgvGiaoVien.AutoGenerateColumns = false;
            dgvGiaoVien.DataSource = _giaovienservice.GetAll().ToList();
        }

        private GiaoVien GetFormData()
        {
            return new GiaoVien
            {
                MaGV = txtMaGV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                GioiTinh = cboGioiTinh.Text,
                NgaySinh = dtpNgaySinh.Value,
                Email = txtEmail.Text.Trim(),
                SDT = txtSDT.Text.Trim(),
                CCCD = txtCCCD.Text.Trim(),
                TrinhDo = txtTrinhDo.Text.Trim(),
                QueQuan = txtQueQuan.Text.Trim()
            };
        }


        private void GiaoVienUI_Load(object sender, EventArgs e)
        {
            LoadData();
        }



        private void dgvGiaoVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            try
            {
                _giaovienservice.Add(GetFormData());
                LoadData();
                MessageBox.Show("Thêm giáo viên thành công");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            LoadData();
        }

        private void btnSua_Click_1(object sender, EventArgs e)
        {
            try
            {
                _giaovienservice.Update(GetFormData());
                LoadData();
                MessageBox.Show("Cập nhật thành công");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (dgvGiaoVien.CurrentRow == null) return;

            string ma = dgvGiaoVien.CurrentRow.Cells["colMaGV"].Value.ToString();

            if (MessageBox.Show("Xóa giáo viên này?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _giaovienservice.Delete(ma);
                LoadData();
            }
        }

        private void ClearForm()
        {
            txtMaGV.Clear();
            txtHoTen.Clear();
            txtEmail.Clear();
            txtSDT.Clear();
            txtCCCD.Clear();
            txtTrinhDo.Clear();
            txtQueQuan.Clear();

            cboGioiTinh.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;

            dgvGiaoVien.ClearSelection();
            txtMaGV.Enabled = true; // cho phép nhập lại mã khi thêm mới
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            ClearForm();
            LoadData();
        }

        private async void btnTimKiem_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim();

            if (string.IsNullOrEmpty(keyword))
            {
                LoadData();
                return;
            }

            var data = await _giaovienservice.SearchAsync(keyword);
            dgvGiaoVien.DataSource = data.ToList();
        }

        private void GiaoVienUI_Load_1(object sender, EventArgs e)
        {

        }

        private void dgvGiaoVien_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dgvGiaoVien.Rows[e.RowIndex];

            txtMaGV.Text = row.Cells["colMaGV"].Value.ToString();
            txtHoTen.Text = row.Cells["colHoTen"].Value.ToString();
            cboGioiTinh.Text = row.Cells["colGioiTinh"].Value.ToString();
            dtpNgaySinh.Value = (DateTime)row.Cells["colNgaySinh"].Value;
            txtEmail.Text = row.Cells["colEmail"].Value.ToString();
            txtSDT.Text = row.Cells["colSDT"].Value.ToString();
            txtCCCD.Text = row.Cells["colCCCD"].Value.ToString();
            txtTrinhDo.Text = row.Cells["colTrinhDo"].Value.ToString();
            txtQueQuan.Text = row.Cells["colQueQuan"].Value.ToString();
        }
    }
}
