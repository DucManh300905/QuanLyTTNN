﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class MainUI : Form
    {
        public MainUI()
        {
            InitializeComponent();
        }

        private void btnHocVien_Click(object sender, EventArgs e)
        {
            // Mở form quản lý học viên
            HocVienUI hocVienUI = new HocVienUI();
            hocVienUI.Show();

            this.Hide();
        }

        private void btnGiaoVien_Click(object sender, EventArgs e)
        {
            GiaoVienUI giaoVienUI = new GiaoVienUI();
            giaoVienUI.Show();
            this.Hide();
        }

        private void btnKhoaHoc_Click(object sender, EventArgs e)
        {
            KhoaHocUI khoaHocUI = new KhoaHocUI();
            khoaHocUI.Show();
            this.Hide();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            DangKyUI dangKyUI = new DangKyUI();
            dangKyUI.Show();
            this.Hide();
        }

        private void btnLopHoc_Click(object sender, EventArgs e)
        {
            LopHocUI lopHocUI = new LopHocUI();
            lopHocUI.Show();
            this.Hide();
        }
    }
}

    /* Tiếp tục với các lớp BLL: Interfaces..., Repositories...
     *                      DAL: Interfaces/IRepositories, Repositories/Repositories, UnitOfwork/ UnitOfwork và IUnitOfWork 
     *                      Entities:...
 
    Yêu cầu và danh sách bài tập lớn 
    Yêu cầu:
    -          Ngôn ngữ và công nghệ : C# WinForms Entity FrameWork, lập trình bất đồng bộ (asynchronous programming)
    -          Cấu trúc: Mô hình 3 lớp (Entity – DAL – BLL – UI) tách thành các Components
    -          Chức năng bắt buộc: CRUD (Thêm – Sửa – Xóa – Tìm kiếm) + Báo cáo thống kê + Xử lý giao dịch (Transaction).
    -            Mở rộng (tùy chọn): Đăng nhập, phân quyền, in báo cáo, xuất Excel/PDF.*/
