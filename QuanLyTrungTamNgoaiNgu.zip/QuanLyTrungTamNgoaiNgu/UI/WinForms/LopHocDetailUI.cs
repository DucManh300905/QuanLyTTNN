﻿using BLL.Interfaces;
using BLL.Repositories;

using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms
{
    public partial class LopHocDetailUI : Form
    {
// Sử dụng Property này để nhận Service từ form cha
        public ILopHocDetailService LopHocDetailService { get; set; }

        private string maLop;
        private string tenLop;
        private string khoaHoc;
        private string maGV;
        private int siSoToiDa;
        private string phongHoc;

        public LopHocDetailUI(string maLop, string tenLop, string khoaHoc, string maGV, int siSo, string phongHoc)
        {
            InitializeComponent();
            this.maLop = maLop;
            this.tenLop = tenLop;
            this.khoaHoc = khoaHoc;
            this.maGV = maGV;
            this.siSoToiDa = siSo;
            this.phongHoc = phongHoc;
        }

        private async void LopHocDetail_Load(object sender, EventArgs e)
        {
            // Hiển thị thông tin ban đầu
            lblMaLop.Text = "Mã lớp: " + maLop;
            lblTenLop.Text = "Tên lớp: " + tenLop;
            lblKhoaHoc.Text = "Khóa học: " + khoaHoc;
            lblGiaoVien.Text = "Giáo viên: " + maGV;
            lblPhongHoc.Text = "Phòng: " + phongHoc;

            // Chỉ cần gọi 1 hàm này để load tất cả
            await LoadAllDataAsync();
        }

        private async Task LoadAllDataAsync()
        {
            try
            {
                if (LopHocDetailService == null) return;

                // 1. Tải danh sách học viên CHƯA CÓ LỚP vào bảng dưới
                var dsCho = await LopHocDetailService.GetHocVienChoLopAsync(this.khoaHoc);
                dgvDangKyChiTiet.DataSource = dsCho.ToList();

                // 2. Tải danh sách học viên TRONG LỚP (Bạn cần bổ sung hàm này ở BLL nếu muốn hiện dgvHocVien)
                // var dsTrongLop = await LopHocDetailService.GetHocVienTrongLopAsync(this.maLop);
                // dgvHocVien.DataSource = dsTrongLop;
                
                // 3. Cập nhật sĩ số thực tế (Giả sử dgvHocVien hiển thị những người trong lớp)
                int siSoHienTai = dgvHocVien.Rows.Count; 
                lblSiSo.Text = $"Sĩ số: {siSoHienTai}/{siSoToiDa}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message);
            }
        }










        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvHocVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // TODO: Implement your code here
        }

        private async void btnThemHV_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem đã chọn học viên ở bảng chờ chưa
            if (dgvDangKyChiTiet.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn học viên từ danh sách đăng ký!");
                return;
            }

            // Lấy MaHV từ cột MaHVChuaCoLop (Hãy chắc chắn bạn đặt đúng DataPropertyName trong Designer)
            string maHV = dgvDangKyChiTiet.CurrentRow.Cells["MaHVChuaCoLop"].Value.ToString();
            string hoTen = dgvDangKyChiTiet.CurrentRow.Cells["HoTenChuaCoLop"].Value.ToString();

            if (MessageBox.Show($"Thêm học viên {hoTen} vào lớp này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                // Gọi Transaction ở BLL
                bool thanhCong = await LopHocDetailService.ThemHocVienVaoLopAsync(this.maLop, maHV);

                if (thanhCong)
                {
                    MessageBox.Show("Thêm thành công!");
                    await LoadAllDataAsync(); // Load lại để học viên biến mất khỏi bảng chờ
                }
                else
                {
                    MessageBox.Show("Thêm thất bại! Vui lòng kiểm tra lại (Lớp có thể đã đầy).");
                }
            }
        }

        private void btnSuaHV_Click(object sender, EventArgs e)
        {
            // TODO: Implement your code here
        }

        private void btnXoaHV_Click(object sender, EventArgs e)
        {
            // TODO: Implement your code here
        }

        private void panelHeader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelHeader_Paint_1(object sender, PaintEventArgs e)
        {

        }
    }
}
