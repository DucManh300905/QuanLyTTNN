﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Repositories
{
    public class LopHocDetailService : ILopHocDetailService
    {
        private readonly IUnitOfWork _unitOfWork;

        public LopHocDetailService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<object>> GetHocVienChoLopAsync(string maKhoaHoc)
        {
            return await Task.Run(() =>
            {
                // Tải dữ liệu về RAM để tránh lỗi Open DataReader
                var dsMaHVDaCoLop = _unitOfWork.LopHocDetails.Query()
                                                .Select(x => x.MaHocVien)
                                                .ToList();

                var dsDangKy = _unitOfWork.DangKys.Query().ToList();
                var dsDangKyCT = _unitOfWork.DangKyChiTiets.Query().ToList();

                var query = from dkct in dsDangKyCT
                            join dk in dsDangKy on dkct.DangKyId equals dk.DangKyId
                            where dkct.MaKhoaHoc == maKhoaHoc
                            && !dsMaHVDaCoLop.Contains(dk.MaHocVien) // Lọc trên RAM
                            select new
                            {
                                MaHV = dk.MaHocVien,
                                HoTen = dk.TenHocVien,
                                TenKhoaHoc = dkct.KhoaHoc?.TenKhoaHoc
                            };

                return query.ToList();
            });
        }

        public async Task<bool> ThemHocVienVaoLopAsync(string maLop, string maHocVien)
        {
            using (var transaction = _unitOfWork.BeginTransaction())
            {
                try
                {
                    var lop = await _unitOfWork.LopHocs.GetByIdAsync(maLop);
                    if (lop == null) return false;

                    var newDetail = new LopHocDetail
                    {
                        MaLop = maLop,
                        MaHocVien = maHocVien,
                        DiemListening = 0,
                        DiemReading = 0,
                        DiemWriting = 0,
                        DiemSpeaking = 0
                    };

                    _unitOfWork.LopHocDetails.Insert(newDetail);
                    await _unitOfWork.CompleteAsync();

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }
    }
}
