﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Repositories
{
    public class LoginService : ILoginService
    {
        private readonly IUnitOfWork _uow;

        public LoginService()
        {
            _uow = new UnitOfWork();
            SeedTaiKhoan();
        }

        public TaiKhoan DangNhap(string tenDangNhap, string matKhau)
        {
            tenDangNhap = tenDangNhap.Trim();
            matKhau = matKhau.Trim();

            return _uow.TaiKhoans.Query()
                .FirstOrDefault(x =>
                    x.TenDangNhap.Trim().Equals(tenDangNhap, StringComparison.OrdinalIgnoreCase)
                    && x.MatKhau == matKhau);
        }


        public void SeedTaiKhoan()
        {
            if (!_uow.TaiKhoans.Query().Any())
            {
                _uow.TaiKhoans.Insert(new TaiKhoan { TenDangNhap = "admin", MatKhau = "admin123", Quyen = "Admin" });
                _uow.TaiKhoans.Insert(new TaiKhoan { TenDangNhap = "user1", MatKhau = "user123", Quyen = "User" });
                _uow.TaiKhoans.Insert(new TaiKhoan { TenDangNhap = "user2", MatKhau = "user456", Quyen = "User" });

                _uow.Complete();
            }
        }
    }
}


