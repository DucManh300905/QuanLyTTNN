﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Repositories  
{
    public class DangKyService : IDangKyService
    {
        private readonly IUnitOfWork _uow;

        public DangKyService()
        {
            _uow = new UnitOfWork();
        }

        public void DangKyKhoaHoc(string maHocVien, string tenHocVien, List<string> maKhoaHocs)
        {
            if (string.IsNullOrWhiteSpace(maHocVien))
                throw new Exception("Mã học viên không được để trống");

            if (string.IsNullOrWhiteSpace(tenHocVien))
                throw new Exception("Tên học viên không được để trống");

            if (maKhoaHocs == null || maKhoaHocs.Count == 0)
                throw new Exception("Chưa chọn khóa học nào");

            using (var transaction = _uow.BeginTransaction())
            {
                try
                {
                    // ===== 1️⃣ KIỂM TRA HỌC VIÊN =====
                    var hocVien = _uow.HocViens
                        .Query()
                        .FirstOrDefault(hv => hv.MaHocVien == maHocVien);


                    if (hocVien == null)
                        throw new Exception("Không tồn tại học viên");

                    if (!hocVien.HoTen.Trim()
                        .Equals(tenHocVien.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        throw new Exception("Tên học viên không khớp với mã học viên");
                    }


                    // ===== 2️⃣ KIỂM TRA ĐĂNG KÝ TRÙNG =====
                    // ===== LOAD ĐĂNG KÝ CỦA HỌC VIÊN =====
                    var dangKyIds = _uow.DangKys
                        .Query()
                        .Where(dk => dk.MaHocVien == maHocVien)
                        .Select(dk => dk.DangKyId)
                        .ToList();

                    var khoaHocDaDangKy = _uow.DangKyChiTiets
                        .Query()
                        .Where(ct => dangKyIds.Contains(ct.DangKyId))
                        .Select(ct => ct.MaKhoaHoc)
                        .ToList();
                    foreach (var maKH in maKhoaHocs)
                    {
                        if (khoaHocDaDangKy.Contains(maKH))
                            throw new Exception($"Học viên đã đăng ký khóa học {maKH}");
                    }



                    // ===== 3️⃣ TÍNH TỔNG TIỀN =====
                    decimal tongTien = 0;
                    foreach (var maKH in maKhoaHocs)
                    {
                        var khoaHoc = _uow.KhoaHocs.GetById(maKH);
                        if (khoaHoc == null)
                            throw new Exception($"Khóa học {maKH} không tồn tại");

                        tongTien += khoaHoc.HocPhi;
                    }

                    // ===== 4️⃣ INSERT DANGKY =====
                    var dangKy = new DangKy
                    {
                        MaHocVien = maHocVien,
                        TenHocVien = tenHocVien,
                        NgayDangKy = DateTime.Now,
                        TongTien = tongTien
                    };

                    _uow.DangKys.Insert(dangKy);
                    _uow.Complete(); // LẤY DangKyId

                    // ===== 5️⃣ INSERT CHI TIẾT =====
                    foreach (var maKH in maKhoaHocs)
                    {
                        var khoaHoc = _uow.KhoaHocs.GetById(maKH);

                        var ct = new DangKyChiTiet
                        {
                            DangKyId = dangKy.DangKyId,
                            MaKhoaHoc = maKH,
                            HocPhi = khoaHoc.HocPhi
                        };

                        _uow.DangKyChiTiets.Insert(ct);
                    }

                    _uow.Complete();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    var error = ex.InnerException?.InnerException?.Message
                                ?? ex.InnerException?.Message
                                ?? ex.Message;

                    throw new Exception(error);
                }

            }
        }
    }
}
