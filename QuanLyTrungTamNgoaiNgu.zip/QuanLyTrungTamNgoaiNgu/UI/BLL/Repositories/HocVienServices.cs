﻿using BLL.Interfaces;
using DAL;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


namespace BLL.Repositories
{
    public class HocVienService : IHocVienService
    {
        private readonly IUnitOfWork _uow;

        public HocVienService()
        {
            _uow = new UnitOfWork();
        }

        public IEnumerable<HocVien> GetAll()
        {
            return _uow.HocViens.Query();
        }

        public void Add(HocVien hv)
        {
            if (string.IsNullOrEmpty(hv.MaHocVien))
                throw new Exception("Mã học viên không được rỗng");

            _uow.HocViens.Insert(hv);
            _uow.Complete();
        }

        public void Update(HocVien hv)
        {
            var entity = _uow.HocViens.GetById(hv.MaHocVien);
            if (entity == null)
                throw new Exception("Không tìm thấy học viên");

            entity.HoTen = hv.HoTen;
            entity.GioiTinh = hv.GioiTinh;
            entity.NgaySinh = hv.NgaySinh;
            entity.Email = hv.Email;
            entity.SoDienThoai = hv.SoDienThoai;
            entity.CCCD = hv.CCCD;

            _uow.Complete();
        }

        public void Delete(string maHocVien)
        {
            _uow.HocViens.Delete(maHocVien);
            _uow.Complete();
        }
        // 🔹 SEARCH ASYNC (MỚI)
        public async Task<IEnumerable<HocVien>> SearchAsync(string keyword)
        {
            keyword = keyword?.ToLower() ?? "";

            return await Task.Run(() =>
                _uow.HocViens.Query()
                    .Where(x =>
                        x.MaHocVien.ToLower().Contains(keyword) ||
                        x.HoTen.ToLower().Contains(keyword) ||
                        (x.Email != null && x.Email.ToLower().Contains(keyword)) ||
                        x.SoDienThoai.Contains(keyword) ||
                        x.CCCD.Contains(keyword))
                    .ToList()
            );
        }

    }
}
