﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Repositories
{
    public class GiaoVienService : IGiaoVienService
    {
        private readonly IUnitOfWork _uow = new UnitOfWork();

        public IEnumerable<GiaoVien> GetAll()
            => _uow.GiaoViens.Query();

        public void Add(GiaoVien gv)
        {
            if (string.IsNullOrEmpty(gv.MaGV))
                throw new Exception("Mã giáo viên không được rỗng");

            _uow.GiaoViens.Insert(gv);
            _uow.Complete();
        }

        public void Update(GiaoVien gv)
        {
            var entity = _uow.GiaoViens.GetById(gv.MaGV);
            if (entity == null)
                throw new Exception("Không tìm thấy giáo viên");

            entity.HoTen = gv.HoTen;
            entity.GioiTinh = gv.GioiTinh;
            entity.NgaySinh = gv.NgaySinh;
            entity.Email = gv.Email;
            entity.SDT = gv.SDT;
            entity.CCCD = gv.CCCD;
            entity.TrinhDo = gv.TrinhDo;
            entity.QueQuan = gv.QueQuan;
            _uow.Complete();
        }

        public void Delete(string id)
        {
            _uow.GiaoViens.Delete(id);
            _uow.Complete();
        }


        // 🔹 SEARCH ASYNC (MỚI)
        public async Task<IEnumerable<GiaoVien>> SearchAsync(string keyword)
        {
            keyword = keyword?.ToLower() ?? "";

            // không có async repo → chạy nền
            return await Task.Run(() =>
                _uow.GiaoViens.Query()
                    .Where(x =>
                        x.MaGV.ToLower().Contains(keyword) ||
                        x.HoTen.ToLower().Contains(keyword) ||
                        (x.Email != null && x.Email.ToLower().Contains(keyword)))
                    .ToList()
            );
        }
    }
}
