﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Repositories
{
    public class LopHocService : ILopHocService
    {
        private readonly IUnitOfWork _uow;

        public LopHocService()
        {
            _uow = new UnitOfWork();
        }

        // ================= GET ALL =================
        public IEnumerable<LopHoc> GetAll()
        {
            return _uow.LopHocs.Query();
        }

        // ================= ADD =================
        public void Add(LopHoc lopHoc)
        {
            if (string.IsNullOrEmpty(lopHoc.MaLop))
                throw new Exception("Mã lớp không được rỗng");

            _uow.LopHocs.Insert(lopHoc);
            _uow.Complete();
        }

        // ================= UPDATE =================
        public void Update(LopHoc lopHoc)
        {
            _uow.LopHocs.Update(lopHoc);
            _uow.Complete();
        }

        // ================= DELETE =================
        public void Delete(string maLop)
        {
            _uow.LopHocs.Delete(maLop);
            _uow.Complete();
        }

        // ================= SEARCH ASYNC =================
        public async Task<IEnumerable<LopHoc>> SearchAsync(string keyword)
        {
            keyword = keyword?.ToLower() ?? "";

            return await Task.Run(() =>
                _uow.LopHocs.Query()
                    .Where(x =>
                        x.MaLop.ToLower().Contains(keyword) ||
                        x.MaKhoaHoc.ToLower().Contains(keyword) ||
                        (x.PhongHoc != null && x.PhongHoc.ToLower().Contains(keyword))
                    )
                    .ToList()
            );
        }


    }
}
