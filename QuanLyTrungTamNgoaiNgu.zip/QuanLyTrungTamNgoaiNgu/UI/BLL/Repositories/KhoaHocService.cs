﻿using BLL.Interfaces;
using DAL.UnitOfwork;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace BLL.Repositories
{
    public class KhoaHocService : IKhoaHocService
    {
        private readonly IUnitOfWork _unitOfWork;

        public KhoaHocService()
        {
            _unitOfWork = new UnitOfWork();
        }

        // ================= GET ALL (SYNC) =================
        public IEnumerable<KhoaHoc> GetAll()
        {
            return _unitOfWork.KhoaHocs.Query();
        }

        // ================= ADD =================
        public void Add(KhoaHoc entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            if (string.IsNullOrWhiteSpace(entity.MaKhoaHoc))
                throw new Exception("Mã khóa học không được để trống");

            if (string.IsNullOrWhiteSpace(entity.TenKhoaHoc))
                throw new Exception("Tên khóa học không được để trống");

            // Check trùng mã
            var existed = _unitOfWork.KhoaHocs.GetById(entity.MaKhoaHoc);
            if (existed != null)
                throw new Exception("Mã khóa học đã tồn tại");

            _unitOfWork.KhoaHocs.Insert(entity);
            _unitOfWork.Complete();
        }

        // ================= UPDATE =================
        public void Update(KhoaHoc entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            var existed = _unitOfWork.KhoaHocs.GetById(entity.MaKhoaHoc);
            if (existed == null)
                throw new Exception("Không tìm thấy khóa học");

            existed.TenKhoaHoc = entity.TenKhoaHoc;
            existed.TrinhDo = entity.TrinhDo;
            existed.SoBuoi = entity.SoBuoi;
            existed.ThoiLuong = entity.ThoiLuong;
            existed.HocPhi = entity.HocPhi;

            _unitOfWork.KhoaHocs.Update(existed);
            _unitOfWork.Complete();
        }

        // ================= DELETE =================
        public void Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new Exception("Mã khóa học không hợp lệ");

            var existed = _unitOfWork.KhoaHocs.GetById(id);
            if (existed == null)
                throw new Exception("Không tìm thấy khóa học");

            _unitOfWork.KhoaHocs.Delete(id);
            _unitOfWork.Complete();
        }

        // ================= SEARCH (ASYNC) =================
        public async Task<IEnumerable<KhoaHoc>> SearchAsync(string keyword)
        {
            var list = await _unitOfWork.KhoaHocs.GetAllAsync();

            if (string.IsNullOrWhiteSpace(keyword))
                return list;

            keyword = keyword.ToLower();

            return list.Where(x =>
                   x.MaKhoaHoc.ToLower().Contains(keyword)
                || x.TenKhoaHoc.ToLower().Contains(keyword)
                || (!string.IsNullOrEmpty(x.TrinhDo) && x.TrinhDo.ToLower().Contains(keyword))
            );
        }
    }
}
