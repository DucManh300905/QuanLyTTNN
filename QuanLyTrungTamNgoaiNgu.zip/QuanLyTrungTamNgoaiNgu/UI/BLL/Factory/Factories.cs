﻿using BLL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factory
{
    public static class ServiceFactory
    {
        public static ILopHocDetailService GetLopHocDetailService()
        {
            // Chỉ có ở đây mới biết UnitOfWork (DAL)
            var unitOfWork = new DAL.UnitOfwork.UnitOfWork();
            return new BLL.Repositories.LopHocDetailService(unitOfWork);
        }
    }
}
