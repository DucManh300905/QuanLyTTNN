﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Interfaces
{
    public interface ILopHocDetailService
    {
        Task<IEnumerable<object>> GetHocVienChoLopAsync(string maKhoaHoc);
        Task<bool> ThemHocVienVaoLopAsync(string maLop, string maHocVien);

    }
}
