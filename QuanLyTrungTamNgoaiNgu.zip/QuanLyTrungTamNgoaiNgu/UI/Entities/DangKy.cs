﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
public class DangKy
{

        [Key]
        public int DangKyId { get; set; }

        [Required]
        [StringLength(10)]
        public string MaHocVien { get; set; }

        [Required]
        [StringLength(100)]
        public string TenHocVien { get; set; }

        public DateTime NgayDangKy { get; set; }

        public decimal TongTien { get; set; }

        // Navigation
        public virtual ICollection<DangKyChiTiet> ChiTietDangKys { get; set; }
    }
}

