﻿using System.ComponentModel.DataAnnotations;

namespace Entities
{
    public class LopHocDetail
    {
        [Key]
        public int LopHocChiTietId { get; set; }

        [Required]
        [StringLength(10)]
        public string MaLop { get; set; }

        // Khóa ngoại mới để khớp với bảng DangKies
        public int DangKyId { get; set; }

        // Giữ lại cột này nếu bạn đã lỡ ALTER TABLE trong SQL
        [StringLength(10)]
        public string MaHocVien { get; set; }

        public decimal? DiemListening { get; set; }
        public decimal? DiemReading { get; set; }
        public decimal? DiemWriting { get; set; }
        public decimal? DiemSpeaking { get; set; }

        // Navigation
        public virtual LopHoc LopHoc { get; set; }
        public virtual DangKy DangKy { get; set; }
    }
}