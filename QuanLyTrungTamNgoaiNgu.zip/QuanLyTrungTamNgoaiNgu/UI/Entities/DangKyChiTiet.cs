﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class DangKyChiTiet
    {
        [Key]
        public int DangKyChiTietId { get; set; }

        [Required]
        public int DangKyId { get; set; }

        [Required]
        [StringLength(10)]
        public string MaKhoaHoc { get; set; }

        public decimal HocPhi { get; set; }

        // Navigation
        [ForeignKey("DangKyId")]
        public virtual DangKy DangKy { get; set; }

        [ForeignKey("MaKhoaHoc")]
        public virtual KhoaHoc KhoaHoc { get; set; }
    }
}
