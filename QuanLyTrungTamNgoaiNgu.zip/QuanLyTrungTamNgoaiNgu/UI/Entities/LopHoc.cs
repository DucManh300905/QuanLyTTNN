﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class LopHoc
    {
        [Key]
        [StringLength(10)]
        public string MaLop { get; set; }

        [Required]
        [StringLength(10)]
        public string MaKhoaHoc { get; set; }
        [StringLength(50)]
        public string TenLop { get; set; }

        [Required]
        public string MaGV { get; set; }

        public int SiSoToiDa { get; set; }

        [StringLength(20)]
        public string PhongHoc { get; set; }

        // Navigation
        public virtual KhoaHoc KhoaHoc { get; set; }
        public virtual GiaoVien GiaoVien { get; set; }
    }

}
