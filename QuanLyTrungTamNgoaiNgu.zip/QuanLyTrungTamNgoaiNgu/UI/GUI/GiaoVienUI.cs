﻿using LanguageCenter.BUS;
using LanguageCenter.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanguageCenter.UI
{
    public partial class GiaoVienUI : Form
    {
        GiaoVienBLL bll = new GiaoVienBLL();
        private GiaoVienBLL giaoVienBLL = new GiaoVienBLL();

        private void LoadDataGiaoVien()
        {
            dgvGiaoVien.DataSource = giaoVienBLL.LayDanhSachGiaoVien();
        }


        public GiaoVienUI()
        {
            InitializeComponent();
            this.Load += GiaoVienUI_Load;
            LoadDataGiaoVien();
            LoadCboTimNgonNgu();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void rdoNu_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdoNam_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void GiaoVienUI_Load(object sender, EventArgs e)
        {
            cboNgonNgu.Items.Clear();
            cboNgonNgu.Items.Add("Tiếng Anh");
            cboNgonNgu.Items.Add("Tiếng Nhật");

            LoadData(); // load dgv
        }
        private void LoadData()
        {
            dgvGiaoVien.AutoGenerateColumns = true;
            dgvGiaoVien.DataSource = bll.LayDanhSachGiaoVien();
        }

        private void dgvGiaoVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Không click header
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvGiaoVien.Rows[e.RowIndex];

            txtMaGV.Text = row.Cells["MaGV"].Value?.ToString();
            txtHoTen.Text = row.Cells["HoTen"].Value?.ToString();
            txtSoDienThoai.Text = row.Cells["SoDienThoai"].Value?.ToString();
            txtEmail.Text = row.Cells["Email"].Value?.ToString();
            txtCCCD.Text = row.Cells["CCCD"].Value?.ToString();
            txtTrinhDo.Text = row.Cells["TrinhDo"].Value?.ToString();
            txtDiaChi.Text = row.Cells["DiaChi"].Value?.ToString();

            // DateTimePicker
            if (row.Cells["NgaySinh"].Value != null)
                dateTime.Value = Convert.ToDateTime(row.Cells["NgaySinh"].Value);

            // RadioButton giới tính
            string gioiTinh = row.Cells["GioiTinh"].Value?.ToString();
            if (gioiTinh == "Nam")
                rdoNam.Checked = true;
            else if (gioiTinh == "Nữ")
                rdoNu.Checked = true;

            // ComboBox Ngoại ngữ
            cboNgonNgu.SelectedItem = row.Cells["NgoaiNgu"].Value?.ToString();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            dgvGiaoVien.DataSource =
                giaoVienBLL.TimKiemGiaoVien(
                    txtTimMaGV.Text.Trim(),
                    txtTimTenGV.Text.Trim(),
                    cboTimNgonNgu.Text
                );
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtTimMaGV.Clear();
            txtTimTenGV.Clear();
            cboTimNgonNgu.SelectedIndex = -1;
            cboTimNgonNgu.Text = "";

            // Load lại toàn bộ dữ liệu
            LoadDataGiaoVien();
            ClearInput();
        }
        private void LoadCboTimNgonNgu()
        {
            cboTimNgonNgu.Items.Clear();
            cboTimNgonNgu.Items.Add("Tiếng Anh");
            cboTimNgonNgu.Items.Add("Tiếng Nhật");

            cboTimNgonNgu.SelectedIndex = -1; // không chọn mặc định
            cboTimNgonNgu.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn thoát không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                this.Close();   // đóng form hiện tại
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (!IsValidInput())
            {
                MessageBox.Show(
                    "Vui lòng nhập đầy đủ tất cả thông tin!",
                    "Thiếu dữ liệu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            GiaoVien gv = new GiaoVien
            {
                MaGV = txtMaGV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                GioiTinh = rdoNam.Checked ? "Nam" : "Nữ",
                NgaySinh = dateTime.Value,
                SoDienThoai = txtSoDienThoai.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                CCCD = txtCCCD.Text.Trim(),
                NgoaiNgu = cboNgonNgu.Text,
                TrinhDo = txtTrinhDo.Text.Trim(),
                DiaChi = txtDiaChi.Text.Trim()
            };

            bool result = giaoVienBLL.InsertGiaoVien(gv);

            if (result)
            {
                MessageBox.Show("Thêm giáo viên thành công!");
                LoadDataGiaoVien();
                ClearInput();
            }
            else
            {
                MessageBox.Show("Mã giáo viên đã tồn tại!");
            }
        }
        private bool IsValidInput()
        {
            if (string.IsNullOrWhiteSpace(txtMaGV.Text) ||
                string.IsNullOrWhiteSpace(txtHoTen.Text) ||
                string.IsNullOrWhiteSpace(txtSoDienThoai.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtCCCD.Text) ||
                string.IsNullOrWhiteSpace(txtTrinhDo.Text) ||
                string.IsNullOrWhiteSpace(txtDiaChi.Text) ||
                cboNgonNgu.SelectedIndex == -1 ||
                (!rdoNam.Checked && !rdoNu.Checked))
            {
                return false;
            }
            return true;
        }
        private void ClearInput()
        {
            txtMaGV.Clear();
            txtHoTen.Clear();
            txtSoDienThoai.Clear();
            txtEmail.Clear();
            txtCCCD.Clear();
            txtTrinhDo.Clear();
            txtDiaChi.Clear();

            cboNgonNgu.SelectedIndex = -1;
            rdoNam.Checked = false;
            rdoNu.Checked = false;
            dateTime.Value = DateTime.Now;
        }

        private void dgvGiaoVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvGiaoVien.Rows[e.RowIndex];

            txtMaGV.Text = row.Cells["MaGV"].Value.ToString();
            txtHoTen.Text = row.Cells["HoTen"].Value.ToString();
            txtSoDienThoai.Text = row.Cells["SoDienThoai"].Value.ToString();
            txtEmail.Text = row.Cells["Email"].Value.ToString();
            txtCCCD.Text = row.Cells["CCCD"].Value.ToString();
            txtTrinhDo.Text = row.Cells["TrinhDo"].Value.ToString();
            txtDiaChi.Text = row.Cells["DiaChi"].Value.ToString();

            cboNgonNgu.Text = row.Cells["NgoaiNgu"].Value.ToString();
            dateTime.Value = Convert.ToDateTime(row.Cells["NgaySinh"].Value);

            string gioiTinh = row.Cells["GioiTinh"].Value.ToString();
            rdoNam.Checked = gioiTinh == "Nam";
            rdoNu.Checked = gioiTinh == "Nữ";

            // Không cho sửa mã
            txtMaGV.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaGV.Text))
            {
                MessageBox.Show("Vui lòng chọn giáo viên cần sửa!");
                return;
            }

            if (!IsValidInput())
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            GiaoVien gv = new GiaoVien
            {
                MaGV = txtMaGV.Text,
                HoTen = txtHoTen.Text.Trim(),
                GioiTinh = rdoNam.Checked ? "Nam" : "Nữ",
                NgaySinh = dateTime.Value,
                SoDienThoai = txtSoDienThoai.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                CCCD = txtCCCD.Text.Trim(),
                NgoaiNgu = cboNgonNgu.Text,
                TrinhDo = txtTrinhDo.Text.Trim(),
                DiaChi = txtDiaChi.Text.Trim()
            };

            bool result = giaoVienBLL.UpdateGiaoVien(gv);

            if (result)
            {
                MessageBox.Show("Cập nhật thành công!");
                LoadDataGiaoVien();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại!");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaGV.Text))
            {
                MessageBox.Show("Vui lòng chọn giáo viên cần xóa!");
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Bạn có chắc chắn muốn xóa giáo viên này không?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (dr == DialogResult.No)
                return;

            string maGV = txtMaGV.Text;

            bool result = giaoVienBLL.DeleteGiaoVien(maGV);

            if (result)
            {
                MessageBox.Show("Xóa giáo viên thành công!");
                LoadDataGiaoVien();
                ClearInput();
            }
            else
            {
                MessageBox.Show("Xóa giáo viên thất bại!");
            }
        }
    }
}
