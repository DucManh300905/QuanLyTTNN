﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LanguageCenter.BUS;
using LanguageCenter.DTO;
using LanguageCenter.UI;


namespace UI
{
    public partial class LopHocUI : Form
    {
        LopHocBLL bll = new LopHocBLL();
        KhoaHocBLL khoaHocBLL = new KhoaHocBLL();
        GiaoVienBLL giaoVienBLL = new GiaoVienBLL();
        private LopHocBLL lopHocBLL = new LopHocBLL();
        public LopHocUI()
        {
            InitializeComponent();
            this.Load += LopHocUI_Load;
        }
        private void LoadKhoaHoc()
        {
            cboKhoaHoc.DataSource = khoaHocBLL.GetAllKhoaHoc();
            cboKhoaHoc.DisplayMember = "TenKhoaHoc";
            cboKhoaHoc.ValueMember = "MaKH";
            cboKhoaHoc.SelectedIndex = -1;
        }
        private void LoadGiaoVien()
        {
            cboGiaoVien.DataSource = giaoVienBLL.LayDanhSachGiaoVien();
            cboGiaoVien.DisplayMember = "HoTen";
            cboGiaoVien.ValueMember = "MaGV";
            cboGiaoVien.SelectedIndex = -1;
        }

        private void LoadLopHoc()
        {
            flpLopHoc.Controls.Clear();
            DataTable ds = lopHocBLL.LayDanhSachLopHoc();

            foreach (DataRow row in ds.Rows)
            {
                flpLopHoc.Controls.Add(TaoGroupBoxLop(row));
            }
        }
        //private void LoadLopHoc()
        // {
        //   flpLopHoc.Controls.Clear();
        // var ds = lopHocBLL.LayDanhSachLopHoc();
        //
        //foreach (var lh in ds)
        //{
        //   flpLopHoc.Controls.Add(TaoGroupBoxLop(lh));
        //}
        //}

        private void LopHocUI_Load(object sender, EventArgs e)
        {

            LoadKhoaHoc();
            LoadGiaoVien();
            LoadLopHoc();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private GroupBox TaoGroupBoxLop(DataRow row)
        {
            GroupBox gb = new GroupBox();
            gb.Width = 300;
            gb.Height = 160;
            gb.Text = row["TenLop"].ToString();
            gb.Tag = row["MaLop"].ToString(); // ⭐ LƯU MaLop

            Label lblMa = new Label()
            {
                Text = "Mã lớp: " + row["MaLop"],
                Location = new Point(10, 25),
                AutoSize = true
            };

            Label lblSiSo = new Label()
            {
                Text = $"Sĩ số: {row["SiSo"]}/{row["SiSoToiDa"]}",
                Location = new Point(10, 50),
                AutoSize = true
            };

            Label lblNgay = new Label()
            {
                Text = "Bắt đầu: " +
                       Convert.ToDateTime(row["NgayBatDau"]).ToString("dd/MM/yyyy"),
                Location = new Point(10, 75),
                AutoSize = true
            };

            Button btnChiTiet = new Button()
            {
                Text = "Chi tiết",
                Location = new Point(10, 105),
                Width = 80
            };

            btnChiTiet.Click += (s, e) =>
            {
                string maLop = gb.Tag.ToString();
                ChiTietLopHocUI frm = new ChiTietLopHocUI(maLop);
                frm.ShowDialog();
                LoadLopHoc();
            };

            gb.Controls.Add(lblMa);
            gb.Controls.Add(lblSiSo);
            gb.Controls.Add(lblNgay);
            gb.Controls.Add(btnChiTiet);

            return gb;
        }


        /* private GroupBox TaoGroupBoxLop(LopHoc lh)
         {
             GroupBox gb = new GroupBox();
             gb.Width = 300;
             gb.Height = 160;
             gb.Text = lh.TenLop;
             gb.Tag = lh.MaLop; // ⭐ LƯU MaLop Ở ĐÂY

             Label lblMa = new Label()
             {
                 Text = "Mã lớp: " + lh.MaLop,
                 Location = new Point(10, 25),
                 AutoSize = true
             };

             Label lblSiSo = new Label()
             {
                 Text = $"Sĩ số: {lh.SiSo}/{lh.SiSoToiDa}",
                 Location = new Point(10, 50),
                 AutoSize = true
             };

             Label lblNgay = new Label()
             {
                 Text = "Bắt đầu: " + lh.NgayBatDau.ToString("dd/MM/yyyy"),
                 Location = new Point(10, 75),
                 AutoSize = true
             };

             Button btnChiTiet = new Button()
             {
                 Text = "Chi tiết",
                 Location = new Point(10, 105),
                 Width = 80
             };

             // ⭐ GẮN EVENT
             btnChiTiet.Click += (s, e) =>
             {
                 string maLop = gb.Tag.ToString();
                 ChiTietLopHocUI frm = new ChiTietLopHocUI(maLop);
                 frm.ShowDialog();
                 LoadLopHoc();
             };

             gb.Controls.Add(lblMa);
             gb.Controls.Add(lblSiSo);
             gb.Controls.Add(lblNgay);
             gb.Controls.Add(btnChiTiet);

             return gb;
         }
        */
        private void btnThemLop_Click_1(object sender, EventArgs e)
        {
            if (cboKhoaHoc.SelectedIndex == -1 || cboGiaoVien.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn khóa học và giáo viên");
                return;
            }

            LopHoc lh = new LopHoc()
            {
                MaLop = txtMaLop.Text.Trim(),
                TenLop = txtTenLop.Text.Trim(),
                MaKH = cboKhoaHoc.SelectedValue.ToString(),
                MaGV = cboGiaoVien.SelectedValue.ToString(),
                SiSoToiDa = int.Parse(txtSiSo.Text),
                NgayBatDau = DateTime.Value
            };

            if (lopHocBLL.ThemLop(lh, out string error))
            {
                LoadLopHoc(); 
                MessageBox.Show("Thêm lớp thành công");
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void cboGiaoVien_Format(object sender, ListControlConvertEventArgs e)
        {
            if (e.ListItem is GiaoVien gv)
            {
                e.Value = $"{gv.HoTen} ({gv.MaGV})";
            }
        }

        private void cboKhoaHoc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaLop.Text))
            {
                MessageBox.Show("Vui lòng nhập mã lớp cần xóa");
                return;
            }

            string maLop = txtMaLop.Text.Trim();

            DialogResult result = MessageBox.Show(
                $"Bạn có chắc muốn xóa lớp {maLop}?\nToàn bộ học viên và điểm sẽ bị xóa!",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No) return;

            if (lopHocBLL.XoaLopHoc(maLop))
            {
                MessageBox.Show("Xóa lớp thành công");
                LoadLopHoc();
            }
            else
            {
                MessageBox.Show("Xóa lớp thất bại");
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
