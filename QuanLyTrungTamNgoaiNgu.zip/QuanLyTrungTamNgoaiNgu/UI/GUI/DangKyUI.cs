﻿using LanguageCenter.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class DangKyUI : Form
    {
        DangKyBLL bll = new DangKyBLL();
        public DangKyUI()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dgvKhoaHoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DangKyUI_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            dgvKhoaHoc.DataSource = bll.GetAllKhoaHoc();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // 1️⃣ Kiểm tra đã chọn khóa học chưa (PHẢI là dgvKhoaHoc)
            if (dgvKhoaHoc.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn khóa học!");
                return;
            }

            // 2️⃣ Lấy dữ liệu
            string maHV = txtMaHVDangKy.Text.Trim();
            string tenHV = txtTenHVDangKy.Text.Trim();
            string maKH = dgvKhoaHoc.CurrentRow.Cells["MaKH"].Value.ToString();

            // 3️⃣ Gọi BLL
            string thongBao;
            bool kq = bll.DangKyKhoaHoc(maHV, tenHV, maKH, out thongBao);

            MessageBox.Show(thongBao);

            // 4️⃣ Load lại danh sách đã đăng ký
            if (kq)
            {
                LoadDgvDangKy();
            }
        }
        private void LoadDgvDangKy()
        {
            string maHV = txtMaHVDangKy.Text.Trim();

            if (string.IsNullOrEmpty(maHV))
                return;

            dgvDangKy.DataSource = null; // ⭐ reset
            dgvDangKy.DataSource = bll.GetKhoaHocDaDangKy(maHV);
        }

        private void txtMaHVDangKy_TextChanged(object sender, EventArgs e)
        {
            LoadDgvDangKy();
        }

        private void txtTenHVDangKy_TextChanged(object sender, EventArgs e)
        {
            LoadDgvDangKy();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDangKy.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn khóa học cần xóa!");
                return;
            }

            string maHV = txtMaHVDangKy.Text.Trim(); 
            string maKH = dgvDangKy.CurrentRow
                .Cells["MaKH"].Value.ToString();

            try
            {
                bll.DeleteDangKy(maHV, maKH);

                MessageBox.Show("Xóa đăng ký thành công!");
                LoadDgvDangKy();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            dgvKhoaHoc.DataSource = null;

            dgvKhoaHoc.DataSource = bll.TimKhoaHoc(
                txtMaKH.Text.Trim(),
                txtTenKhoaHoc.Text.Trim(),
                txtThoiLuong.Text.Trim(),
                txtThanhTien.Text.Trim(),
                cboNgonNgu.Text.Trim(),
                txtTrinhDo.Text.Trim()
            );

            if (dgvKhoaHoc.Rows.Count == 0)
            {
                MessageBox.Show("Không tìm thấy khóa học phù hợp!");
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaKH.Clear();
            txtTenKhoaHoc.Clear();
            txtThoiLuong.Clear();
            txtThanhTien.Clear();
            txtTrinhDo.Clear();
            cboNgonNgu.SelectedIndex = -1;

            dgvKhoaHoc.DataSource = bll.GetAllKhoaHoc();
        }

        private void dgvDangKy_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {

        }
    }
}
