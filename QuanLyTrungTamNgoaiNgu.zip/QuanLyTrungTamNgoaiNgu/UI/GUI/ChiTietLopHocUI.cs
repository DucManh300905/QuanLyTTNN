﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LanguageCenter.BUS;

namespace UI
{
    public partial class ChiTietLopHocUI : Form
    {
        private string maLop;

        private LopHocBLL lopHocBLL = new LopHocBLL();
        private DiemBLL diemBLL = new DiemBLL();

        public ChiTietLopHocUI(string maLop)
        {
            InitializeComponent();
            this.maLop = maLop;

        }

        private void ChiTietLopHocUI_Load(object sender, EventArgs e)
        {

        }


        private void btnThem_Click(object sender, EventArgs e)
        {
            dgvChonHocVien.DataSource = lopHocBLL.LayHocVienChuaTrongLop(maLop);
            dgvChonHocVien.ReadOnly = true;
            dgvChonHocVien.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dgvHienThi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvChonHocVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvChonHocVien_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string maHocVien = dgvChonHocVien.Rows[e.RowIndex]
                                    .Cells["MaHocVien"].Value.ToString();

            if (lopHocBLL.ThemHocVienVaoLop(maHocVien, maLop))
            {
                MessageBox.Show(
                    "Thêm học viên vào lớp thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                // 🔄 Refresh 2 DataGridView
                dgvChonHocVien.DataSource =
                    lopHocBLL.LayHocVienChuaTrongLop(maLop);

                dgvHienThi.DataSource =
                    lopHocBLL.LayHocVienVaDiemTheoLop(maLop);
            }
            else
            {
                MessageBox.Show(
                    "Thêm học viên vào lớp thất bại!",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }


        private void dgvChonHocVien_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvHienThi_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            DataTable dt = lopHocBLL.LayHocVienVaDiemTheoLop(maLop);
            dgvHienThi.DataSource = dt;
            dgvHienThi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            string ngonNgu = lopHocBLL.LayNgonNguTheoMaLop(maLop);

            if (ngonNgu == "Tiếng Anh")
            {
                dgvHienThi.Columns["Listening"].HeaderText = "Nghe";
                dgvHienThi.Columns["Reading"].HeaderText = "Đọc";
                dgvHienThi.Columns["Writing"].HeaderText = "Viết";
                dgvHienThi.Columns["Speaking"].HeaderText = "Nói";
                dgvHienThi.Columns["Overall"].HeaderText = "Overall";

                if (dgvHienThi.Columns.Contains("Overall"))
                    dgvHienThi.Columns["Overall"].ReadOnly = true;
            }
            else if (ngonNgu == "Tiếng Nhật")
            {
                dgvHienThi.Columns["Nghe"].HeaderText = "Nghe";
                dgvHienThi.Columns["Doc"].HeaderText = "Đọc";
                dgvHienThi.Columns["TongDiem"].HeaderText = "Tổng điểm";

                if (dgvHienThi.Columns.Contains("TongDiem"))
                    dgvHienThi.Columns["TongDiem"].ReadOnly = true;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvHienThi.CurrentRow == null)
            {
                MessageBox.Show(
                    "Vui lòng chọn học viên cần xóa!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            string maHocVien = dgvHienThi.CurrentRow
                                .Cells["MaHocVien"]
                                .Value
                                .ToString();

            DialogResult result = MessageBox.Show(
                $"Bạn có chắc muốn xóa học viên {maHocVien} khỏi lớp?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No)
                return;

            if (lopHocBLL.XoaHocVienKhoiLop(maHocVien, maLop))
            {
                MessageBox.Show(
                    "Xóa học viên khỏi lớp thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                // 🔄 Refresh danh sách
                dgvHienThi.DataSource = lopHocBLL.LayHocVienTrongLop(maLop);
                dgvChonHocVien.DataSource = lopHocBLL.LayHocVienChuaTrongLop(maLop);
            }
            else
            {
                MessageBox.Show(
                    "Xóa học viên thất bại!",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnNhapDiem_Click(object sender, EventArgs e)
        {
            if (dgvHienThi.CurrentRow == null) return;

            // ⭐ CỰC KỲ QUAN TRỌNG
            dgvHienThi.EndEdit();

            DataGridViewRow row = dgvHienThi.CurrentRow;

            string maHV = row.Cells["MaHocVien"].Value.ToString();
            string ngonNgu = lopHocBLL.LayNgonNguTheoMaLop(maLop);

            bool ok = false;

            if (ngonNgu == "Tiếng Anh")
            {
                double listening = double.Parse(row.Cells["Listening"].Value?.ToString() ?? "0");
                double reading = double.Parse(row.Cells["Reading"].Value?.ToString() ?? "0");
                double writing = double.Parse(row.Cells["Writing"].Value?.ToString() ?? "0");
                double speaking = double.Parse(row.Cells["Speaking"].Value?.ToString() ?? "0");

                // validate IELTS
                if (listening < 0 || listening > 9 ||
                    reading < 0 || reading > 9 ||
                    writing < 0 || writing > 9 ||
                    speaking < 0 || speaking > 9)
                {
                    MessageBox.Show("Điểm IELTS phải từ 0 đến 9");
                    return;
                }

                ok = diemBLL.CapNhatDiem(
                    maHV, maLop,
                    listening, reading, writing, speaking
                );
            }
            else if (ngonNgu == "Tiếng Nhật")
            {
                int nghe = 0;
                int doc = 0;

                int.TryParse(row.Cells["Nghe"].Value?.ToString(), out nghe);
                int.TryParse(row.Cells["Doc"].Value?.ToString(), out doc);

                // Validate điểm JLPT (0–60 ví dụ)
                if (nghe < 0 || doc < 0 || nghe > 60 || doc > 60)
                {
                    MessageBox.Show("Điểm Nghe và Đọc phải từ 0 đến 60");
                    return;
                }

                ok = diemBLL.CapNhatDiemTiengNhat(
                    maHV,
                    maLop,
                    nghe,
                    doc
                );
            }

            MessageBox.Show(ok ? "Lưu điểm thành công!" : "Lưu điểm thất bại");

            // 🔄 load lại để thấy Overall / Tổng điểm
            dgvHienThi.DataSource = lopHocBLL.LayHocVienVaDiemTheoLop(maLop);
        }


    }
}
