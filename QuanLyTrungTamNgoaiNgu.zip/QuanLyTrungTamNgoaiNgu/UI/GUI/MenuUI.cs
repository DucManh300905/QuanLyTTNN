﻿using LanguageCenter.BUS;
using LanguageCenter.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI;

namespace LanguageCenter.UI
{
    public partial class MenuUI : Form
    {
        DangNhap _user;
        public MenuUI(DangNhap user)
        {
            InitializeComponent();
            _user = user;
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void btnHocVien_Click(object sender, EventArgs e)
        {
            HocVienUI hocVienUI = new HocVienUI();
            hocVienUI.Show();
        }

        private void btnGiaoVien_Click(object sender, EventArgs e)
        {
            GiaoVienUI giaoVienUI = new GiaoVienUI();
            giaoVienUI.Show();
        }

        private void btnKhoaHoc_Click(object sender, EventArgs e)
        {
            KhoaHocUI khoaHocUI = new KhoaHocUI();
            khoaHocUI.Show();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            DangKyUI dangKyUI = new DangKyUI();
            dangKyUI.Show();
        }

        private void btnLopHoc_Click(object sender, EventArgs e)
        {
            LopHocUI lopHocUI = new LopHocUI();
            lopHocUI.Show();
        }
    }
}
