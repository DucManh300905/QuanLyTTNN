﻿using LanguageCenter.BUS;
using LanguageCenter.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class KhoaHocUI : Form
    {
        KhoaHocBLL bll = new KhoaHocBLL();
        public KhoaHocUI()
        {
            InitializeComponent();
        }

        private void KhoaHocUI_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadNgonNgu();
        }

        private void LoadData()
        {
            dgvKhoaHoc.DataSource = bll.GetAllKhoaHoc();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                KhoaHoc kh = new KhoaHoc()
                {
                    MaKH = txtMaKH.Text.Trim(),
                    TenKhoaHoc = txtTenKH.Text.Trim(),
                    ThoiLuong = int.Parse(txtThoiLuong.Text),
                    NgonNgu = cboNgonNgu.Text,
                    TrinhDo = txtCapDo.Text.Trim(),
                    ThanhTien = decimal.Parse(txtThanhTien.Text)
                };

                bool kq = bll.InsertKhoaHoc(kh);

                if (kq)
                {
                    MessageBox.Show("Thêm khóa học thành công!");
                    LoadData();          // load lại dgvKhoaHoc
                    ClearTextBox();      // xóa ô nhập
                }
                else
                {
                    MessageBox.Show("Thêm thất bại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
        private void ClearTextBox()
        {
            txtMaKH.Clear();
            txtTenKH.Clear();
            txtThoiLuong.Clear();
            txtThanhTien.Clear();
            cboNgonNgu.SelectedIndex = -1;
            txtCapDo.Clear();
        }
        private void LoadNgonNgu()
        {
            cboNgonNgu.Items.Clear();
            cboNgonNgu.Items.Add("Tiếng Anh");
            cboNgonNgu.Items.Add("Tiếng Nhật");

            cboNgonNgu.DropDownStyle = ComboBoxStyle.DropDownList;
            cboNgonNgu.SelectedIndex = 0; // chọn mặc định
        }

        private void dgvKhoaHoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtMaKH.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["MaKH"].Value.ToString();
                txtTenKH.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["TenKhoaHoc"].Value.ToString();
                txtThoiLuong.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["ThoiLuong"].Value.ToString();
                cboNgonNgu.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["NgonNgu"].Value.ToString();
                txtCapDo.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["TrinhDo"].Value.ToString();
                txtThanhTien.Text = dgvKhoaHoc.Rows[e.RowIndex].Cells["ThanhTien"].Value.ToString();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                KhoaHoc kh = new KhoaHoc()
                {
                    MaKH = txtMaKH.Text.Trim(),   // KHÓA CHÍNH – KHÔNG ĐƯỢC SỬA
                    TenKhoaHoc = txtTenKH.Text.Trim(),
                    ThoiLuong = int.Parse(txtThoiLuong.Text),
                    NgonNgu = cboNgonNgu.Text,
                    TrinhDo = txtCapDo.Text.Trim(),
                    ThanhTien = decimal.Parse(txtThanhTien.Text)
                };

                bool kq = bll.UpdateKhoaHoc(kh);

                if (kq)
                {
                    MessageBox.Show("Cập nhật khóa học thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật thất bại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaKH.Text))
            {
                MessageBox.Show("Vui lòng chọn khóa học cần xóa!");
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Bạn có chắc chắn muốn xóa khóa học này không?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (dr == DialogResult.Yes)
            {
                bool kq = bll.DeleteKhoaHoc(txtMaKH.Text.Trim());

                if (kq)
                {
                    MessageBox.Show("Xóa khóa học thành công!");
                    LoadData();
                    ClearTextBox();
                }
                else
                {
                    MessageBox.Show("Xóa thất bại!");
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (dr == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
