﻿using BLL.Interfaces;
using BLL.Repositories;
using Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanguageCenter.UI
{
    public partial class HocVienUI : Form
    {
        private readonly IHocVienService _hocVienService;
        public HocVienUI()
        {
            InitializeComponent();
            _hocVienService = new HocVienService();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void HocVienUI_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = _hocVienService.GetAll().ToList();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {

        }

        private void btnThoatHocVien_Click(object sender, EventArgs e)
        {
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {


        }
        private void ClearInput()
        {
            txtMaHV.Clear();
            txtHoTen.Clear();
            txtSdt.Clear();
            txtEmail.Clear();
            DataTime.Value = DateTime.Now;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Lấy dữ liệu từ UI
                var hv = new HocVien
                {
                    MaHocVien = txtMaHV.Text.Trim(),
                    HoTen = txtHoTen.Text.Trim(),
                    NgaySinh = DataTime.Value,
                    SoDienThoai = txtSdt.Text.Trim(),
                    Email = txtEmail.Text.Trim()
                };

                // 2. Gọi BLL để thêm
                _hocVienService.Add(hv);

                // 3. Reload DataGridView
                LoadData();

                // 4. Reset form
                ClearInput();

                MessageBox.Show("Thêm học viên thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {

        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {

        }


    }
}
