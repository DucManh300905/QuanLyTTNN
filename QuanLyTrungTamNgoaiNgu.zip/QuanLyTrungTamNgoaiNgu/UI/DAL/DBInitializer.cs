﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DBInitializer : DropCreateDatabaseIfModelChanges<DBContext>
    {
        protected override void Seed(DBContext context)
        {
            // Dữ liệu mẫu cho TaiKhoan
            context.TaiKhoans.Add(new TaiKhoan
            {
                TenDangNhap = "admin",
                MatKhau = "admin123",
                Quyen = "Admin"
            });

            context.TaiKhoans.Add(new TaiKhoan
            {
                TenDangNhap = "user1",
                MatKhau = "user123",
                Quyen = "User"
            });

            context.TaiKhoans.Add(new TaiKhoan
            {
                TenDangNhap = "user2",
                MatKhau = "user456",
                Quyen = "User"
            });

            // Lưu dữ liệu vào database
            context.SaveChanges();

            base.Seed(context);
        }
    }
}
