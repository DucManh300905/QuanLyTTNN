﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Entities;

namespace DAL
{
    public class DBContext : DbContext
    {
        public DBContext() : base("DBContext")
        {
            //Database.SetInitializer<DBContext>(null);
            //Database.SetInitializer(new DBInitializer());
        }

        public DbSet<HocVien> HocViens { get; set; }
        public DbSet<TaiKhoan> TaiKhoans { get; set; }

        public DbSet<GiaoVien> GiaoViens { get; set; }
        public DbSet<KhoaHoc> KhoaHocs { get; set; }
        public DbSet<DangKy> DangKys { get; set; }
        public DbSet<DangKyChiTiet> DangKyChiTiets { get; set; }
        public DbSet<LopHoc> LopHocs { get; set; }
        public DbSet<LopHocDetail> LopHocDetails { get; set; }



        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Khóa chính
            modelBuilder.Entity<HocVien>().HasKey(x => x.MaHocVien);
            modelBuilder.Entity<GiaoVien>().HasKey(x => x.MaGV);
            modelBuilder.Entity<KhoaHoc>().HasKey(x => x.MaKhoaHoc);

            modelBuilder.Entity<DangKy>().HasKey(x => x.DangKyId);
            modelBuilder.Entity<DangKyChiTiet>().HasKey(x => x.DangKyChiTietId);

            modelBuilder.Entity<LopHocDetail>().HasKey(x => x.LopHocChiTietId);
            modelBuilder.Entity<LopHoc>().HasKey(x => x.MaLop);

            // ===== QUAN HỆ =====

            // ===== LopHoc =====
            modelBuilder.Entity<LopHoc>()
                .HasRequired(x => x.KhoaHoc)
                .WithMany()
                .HasForeignKey(x => x.MaKhoaHoc)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<LopHoc>()
                .HasRequired(x => x.GiaoVien)
                .WithMany()
                .HasForeignKey(x => x.MaGV)
                .WillCascadeOnDelete(false);

            // ===== DangKy =====
            modelBuilder.Entity<DangKy>()
                    .Property(x => x.MaHocVien)
                    .IsRequired()
                    .HasMaxLength(10);

            modelBuilder.Entity<DangKyChiTiet>()
                .HasRequired(x => x.KhoaHoc)
                .WithMany()
                .HasForeignKey(x => x.MaKhoaHoc)
                .WillCascadeOnDelete(false);

            // ===== LopHocDetail =====
            // LopHoc (1) ---- (n) LopHocDetail
            modelBuilder.Entity<LopHocDetail>()
                    .HasRequired(x => x.DangKy)
                    .WithMany()
                    .HasForeignKey(x => x.DangKyId) // Dùng DangKyId (int) làm khóa ngoại
                    .WillCascadeOnDelete(false);

            // Đảm bảo quan hệ LopHocDetail -> LopHoc vẫn đúng
            modelBuilder.Entity<LopHocDetail>()
                .HasRequired(x => x.LopHoc)
                .WithMany()
                .HasForeignKey(x => x.MaLop)
                .WillCascadeOnDelete(false);


            base.OnModelCreating(modelBuilder);
        }

    }
}
