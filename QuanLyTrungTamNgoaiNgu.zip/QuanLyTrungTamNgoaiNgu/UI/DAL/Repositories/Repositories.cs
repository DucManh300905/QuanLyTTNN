﻿    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Data.SqlClient;
    using DAL.Interfaces;



    namespace DAL.Repositories
    {

        public class Repository<T> : IRepository<T> where T : class
        {
            protected readonly DBContext _context;
            protected readonly DbSet<T> _dbSet;

            public Repository(DBContext context)
            {
                _context = context;
                _dbSet = context.Set<T>();
            }

            // ================= SYNC =================

            public IEnumerable<T> Query()
            {
                return _dbSet;
            }

            public T GetById(object id)
            {
                return _dbSet.Find(id);
            }

            // ================= ASYNC =================

            public async Task<List<T>> GetAllAsync()
            {
                return await _dbSet.ToListAsync();
            }

            public async Task<T> GetByIdAsync(object id)
            {
                return await _dbSet.FindAsync(id);
            }

            // ================= CRUD =================

            public void Insert(T entity)
            {
                _dbSet.Add(entity);
            }

            public void Update(T entity)
            {
                _context.Entry(entity).State = EntityState.Modified;
            }

            public void Delete(object id)
            {
                var entity = _dbSet.Find(id);
                if (entity != null)
                    _dbSet.Remove(entity);
            }


        }
    }
