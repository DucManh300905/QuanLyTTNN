﻿using DAL.Interfaces;
using DAL.Repositories;
using Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.UnitOfwork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DBContext _context;

        private IRepository<HocVien> _hocVienRepo;
        private IRepository<TaiKhoan> _taiKhoanRepo;
        private IRepository<GiaoVien> _giaoVienRepo;
        private IRepository<KhoaHoc> _khoaHocRepo;
        private IRepository<DangKy> _dangKyRepo;
        private IRepository<DangKyChiTiet> _dangKyCTRepo;
        private IRepository<LopHoc> _lopHocRepo;
        private IRepository<LopHocDetail> _lopHocDetailRepo;



        public UnitOfWork()
        {
            _context = new DBContext(); // ✅ context KHÔNG BAO GIỜ NULL
        }

        public IRepository<LopHocDetail> LopHocDetails
        {
            get
            {
                if (_lopHocDetailRepo == null)
                    _lopHocDetailRepo = new Repository<LopHocDetail>(_context);
                return _lopHocDetailRepo;
            }
        }

        public IRepository<LopHoc> LopHocs
        {
            get
            {
                if (_lopHocRepo == null)
                    _lopHocRepo = new Repository<LopHoc>(_context);
                return _lopHocRepo;
            }
        }
        public IRepository<DangKy> DangKys
        {
            get
            {
                if (_dangKyRepo == null)
                    _dangKyRepo = new Repository<DangKy>(_context);
                return _dangKyRepo;
            }
        }

        public IRepository<DangKyChiTiet> DangKyChiTiets
        {
            get
            {
                if (_dangKyCTRepo == null)
                    _dangKyCTRepo = new Repository<DangKyChiTiet>(_context);
                return _dangKyCTRepo;
            }
        }

        public IRepository<KhoaHoc> KhoaHocs
        {
            get
            {
                if (_khoaHocRepo == null)
                    _khoaHocRepo = new Repository<KhoaHoc>(_context);
                return _khoaHocRepo;
            }
        }

        public IRepository<GiaoVien> GiaoViens
        {
            get
            {
                if (_giaoVienRepo == null)
                    _giaoVienRepo = new Repository<GiaoVien>(_context);
                return _giaoVienRepo;
            }
        }

        public IRepository<HocVien> HocViens
        {
            get
            {
                if (_hocVienRepo == null)
                    _hocVienRepo = new Repository<HocVien>(_context);
                return _hocVienRepo;
            }
        }

        public IRepository<TaiKhoan> TaiKhoans
        {
            get
            {
                if (_taiKhoanRepo == null)
                    _taiKhoanRepo = new Repository<TaiKhoan>(_context);
                return _taiKhoanRepo;
            }
        }

        // ===== TRANSACTION =====
        public DbContextTransaction BeginTransaction()
        {
            return _context.Database.BeginTransaction();
        }

        // ===== ASYNC =====
        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }
        public int Complete()
        {
            return _context.SaveChanges();
        }


        public void Dispose()
        {
            _context.Dispose();
        }

    }
}
