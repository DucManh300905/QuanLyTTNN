﻿using DAL.Interfaces;
using Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.UnitOfwork
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<HocVien> HocViens { get; }
        IRepository<TaiKhoan> TaiKhoans { get; }
        IRepository<GiaoVien> GiaoViens { get; }
        IRepository<KhoaHoc> KhoaHocs { get; }
        IRepository<DangKy> DangKys { get; }
        IRepository<DangKyChiTiet> DangKyChiTiets { get; }
        IRepository<LopHoc> LopHocs { get; }
        IRepository<LopHocDetail> LopHocDetails { get; }



        int Complete();
        Task<int> CompleteAsync();
        DbContextTransaction BeginTransaction();

    }
}
